package com.hassangamal.srtrenamer

import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.net.Uri
import android.os.*
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import android.view.*
import android.annotation.SuppressLint
import android.webkit.*
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.core.view.GestureDetectorCompat
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.*
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import java.io.*
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

/** بيمثّل موقع torrent واحد مع خطواته */
data class Bt4gSite(
    val name   : String,          // اسم الموقع يظهر في الـ dropdown
    val domain : String,          // https://bitsearch.eu
    val pattern: String,          // /search?q={query}
    val selector: String,         // CSS selector للـ magnet/torrent (فاضي = bt4g flow)  [backward compat]
    val steps  : List<String> = emptyList()  // خطوات متتالية من CSS selectors — لو موجودة بتحل محل selector
)

class MainActivity : AppCompatActivity() {

    // ── Tabs ─────────────────────────────────────────────────────────
    private lateinit var tabSrt   : TextView
    private lateinit var tabBt4g  : TextView
    private lateinit var tabYts   : TextView
    private lateinit var tabAuto  : TextView
    private lateinit var pageSrt  : View
    private lateinit var pageBt4g : View
    private lateinit var pageYts  : View
    private lateinit var pageAuto : View
    private var currentTab = 0
    private var isActivityVisible = false



    // ── SRT Renamer ──────────────────────────────────────────────────
    private lateinit var btnSelectFolder   : Button
    private lateinit var tvFolderPath      : TextView
    private lateinit var layoutModeChoice  : LinearLayout
    private lateinit var btnModeAuto       : Button
    private lateinit var btnModeManual     : Button
    private lateinit var layoutAutoMode    : LinearLayout
    private lateinit var tvDetectedName    : TextView
    private lateinit var btnFetchNow       : Button
    private lateinit var btnOpenSubsource  : Button
    private lateinit var btnCheckDownloads : Button
    private lateinit var layoutManualMode  : LinearLayout
    private lateinit var btnSelectZip      : Button
    private lateinit var tvZipPath         : TextView
    private lateinit var btnRun            : Button
    private lateinit var layoutStatus      : LinearLayout
    private lateinit var progressBar       : ProgressBar
    private lateinit var tvResult          : TextView

    private var selectedFolderUri : Uri?    = null
    private var selectedZipUri    : Uri?    = null
    private var detectedSlug      : String? = null
    private var currentMode       : String  = "none"
    private var wentToSubsource   : Boolean = false

    // ── bt4g ─────────────────────────────────────────────────────────
    private lateinit var bt4gSearchInput        : EditText
    private lateinit var bt4gSearchBtn          : Button
    private lateinit var bt4gProgressBar        : ProgressBar
    private lateinit var bt4gStatusText         : TextView
    private lateinit var bt4gWebView            : WebView
    private lateinit var subsWebView            : WebView
    private lateinit var subsBrowserLabel       : TextView
    private lateinit var bt4gTopSpacer          : View
    private lateinit var bt4gBottomSpacer       : View
    private lateinit var bt4gDomainInput        : EditText
    private lateinit var bt4gDomainSaveBtn      : Button
    private lateinit var bt4gSearchPatternInput : EditText
    private lateinit var bt4gMagnetSelectorInput: EditText
    private lateinit var bt4gSiteLabel          : TextView
    private lateinit var bt4gSiteDropdownBtn    : Button
    private lateinit var bt4gAddSiteBtn         : Button
    private lateinit var bt4gAddStepBtn         : Button
    private lateinit var bt4gSettingsCard        : LinearLayout
    private lateinit var bt4gSettingsBody        : LinearLayout
    private lateinit var bt4gSettingsToggle      : TextView
    private var bt4gSettingsExpanded : Boolean   = true
    private var bt4gPendingQuery  : String? = null
    private var bt4gCfRetries     : Int     = 0
    private var bt4gDomain        : String  = "https://bt4gprx.com"
    private var bt4gSearchPattern : String  = "/search?q={q}&autodl=1"
    private var bt4gMagnetSelector: String  = ""
    private var bt4gSteps         : List<String> = emptyList()  // خطوات متعددة
    private var bt4gCurrentStep   : Int     = 0                  // الخطوة الحالية

    // ── Sites system ──────────────────────────────────────────────────
    private val bt4gSites = mutableListOf<Bt4gSite>()
    private var bt4gCurrentSiteIndex = 0

    private val DEFAULT_SITES = listOf(
        Bt4gSite(
            name     = "bitsearch.eu",
            domain   = "https://bitsearch.eu",
            pattern  = "/search?q={query}",
            selector = "",
            steps    = listOf(
                "h3 a[href^='/torrent/']",              // خطوة 1: اضغط على اسم الفيلم في نتائج البحث
                "a[href*='/download/torrent/']"         // خطوة 2: اضغط على زر Torrent في صفحة التفاصيل
            )
        ),
        Bt4gSite(
            name     = "magnetz.eu",
            domain   = "https://magnetz.eu",
            pattern  = "/search?query={query}",
            selector = "a.magnet-bar__download"
        ),
        Bt4gSite(
            name     = "bt4gprx.com (default)",
            domain   = "https://bt4gprx.com",
            pattern  = "/search?q={q}&autodl=1",
            selector = ""
        )
    )

    // ── YTS ──────────────────────────────────────────────────────────
    private lateinit var ytsSearchInput  : EditText
    private lateinit var ytsSearchBtn    : Button
    private lateinit var ytsProgressBar  : ProgressBar
    private lateinit var ytsStatusText   : TextView
    private lateinit var ytsWebView      : WebView
    private lateinit var ytsTopSpacer    : View
    private lateinit var ytsBottomSpacer : View
    private lateinit var ytsQualityRow   : LinearLayout
    private lateinit var ytsBtn1080      : Button
    private lateinit var ytsBtn2160      : Button
    private lateinit var ytsDomainInput          : EditText
    private lateinit var ytsDomainSaveBtn        : Button
    private lateinit var ytsSearchPatternInput   : EditText
    private lateinit var ytsTorrentSelectorInput : EditText
    private var ytsUrl1080          : String? = null
    private var ytsUrl2160          : String? = null
    private var ytsCfRetries        : Int     = 0
    private var ytsDomain           : String  = "https://yts.mx"
    private var ytsSearchPattern    : String  = "/movies/{q}"       // {q} = slug
    private var ytsTorrentSelector  : String  = "a[href*=\"/torrent/download/\"]"  // CSS selector للتورنت

    // ── SubSource WebView state ──────────────────────────────────
    private var subsCallback     : ((ByteArray?) -> Unit)? = null
    private var subsCfRetries    : Int     = 0
    private var subsUrlQueue     : ArrayDeque<String> = ArrayDeque()
    private var subsCurrentPage  : String? = null
    private var subsLabel        : String  = ""

    // ── Auto Mode ────────────────────────────────────────────────────
    private lateinit var autoWatchFolderBtn   : Button
    private lateinit var autoWatchFolderLabel : TextView
    private lateinit var autoToggleBtn        : Button
    private lateinit var autoStatusIcon       : TextView
    private lateinit var autoLogView          : TextView
    private lateinit var autoLogScroll        : ScrollView
    private lateinit var autoStatsText        : TextView
    private lateinit var autoClearLogBtn      : Button

    private var autoWatchFolderUri : Uri?    = null
    private var autoWatchJob       : Job?    = null
    private var autoRunning        : Boolean = false
    private val autoLogSB          = StringBuilder()
    // Names already processed so we don't re-fetch on every poll
    private val processedNames     = mutableSetOf<String>()
    private var autoSuccessCount   = 0
    private var autoFailCount      = 0

    private val PREFS               = "autosubs_prefs"
    private val KEY_WATCH_URI       = "watch_folder_uri"
    private val KEY_AUTO_RUNNING    = "auto_was_running"
    private val KEY_YTS_DOMAIN      = "yts_domain"
    private val KEY_YTS_PATTERN     = "yts_search_pattern"
    private val KEY_YTS_SELECTOR    = "yts_torrent_selector"
    private val KEY_BT4G_DOMAIN     = "bt4g_domain"
    private val KEY_BT4G_PATTERN    = "bt4g_search_pattern"
    private val KEY_BT4G_SELECTOR   = "bt4g_magnet_selector"
    private val KEY_BT4G_SITES      = "bt4g_sites_json"
    private val KEY_BT4G_SITE_IDX   = "bt4g_site_index"
    private val NOTIF_CHANNEL       = "autosubs_ch"

    // ── Gesture ──────────────────────────────────────────────────────
    private lateinit var gestureDetector : GestureDetectorCompat

    // ── Launchers ────────────────────────────────────────────────────
    private val folderLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { r ->
        if (r.resultCode == RESULT_OK) r.data?.data?.let { uri ->
            try { contentResolver.takePersistableUriPermission(uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION) }
            catch (_: Exception) {}
            selectedFolderUri = uri
            onFolderSelected(uri)
        }
    }

    private val zipLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { r ->
        if (r.resultCode == RESULT_OK) r.data?.data?.let { uri ->
            selectedZipUri = uri
            if (currentMode == "auto") processFiles()
            else {
                tvZipPath.text = getFileName(uri) ?: "ZIP selected"
                tvZipPath.setTextColor(getColor(R.color.color_success))
                checkRunReady()
            }
        }
    }

    private val autoFolderLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { r ->
        if (r.resultCode == RESULT_OK) r.data?.data?.let { uri ->
            try { contentResolver.takePersistableUriPermission(uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION) }
            catch (_: Exception) {}
            autoWatchFolderUri = uri
            autoWatchFolderLabel.text = "📁 ${folderDisplayName(uri)}"
            autoWatchFolderLabel.setTextColor(getColor(R.color.color_success))
            savePrefs()
            autoLog("📁 مجلد: ${folderDisplayName(uri)}")
        }
    }

    // ── onCreate ─────────────────────────────────────────────────────
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        setContentView(R.layout.activity_main)
        createNotifChannel()
        requestNotifPermission()
        bindViews()
        setupTabs()
        setupSwipe()
        setupSrt()
        setupBt4g()
        setupYts()
        setupSubsWebView()
        setupAutoMode()
        resetSrtState()
        handleShareIntent()
        loadPrefs()
    }

    // ── Bind ─────────────────────────────────────────────────────────
    private fun bindViews() {
        tabSrt   = findViewById(R.id.tabSrt)
        tabBt4g  = findViewById(R.id.tabBt4g)
        tabYts   = findViewById(R.id.tabYts)
        tabAuto  = findViewById(R.id.tabAuto)
        pageSrt  = findViewById(R.id.pageSrt)
        pageBt4g = findViewById(R.id.pageBt4g)
        pageYts  = findViewById(R.id.pageYts)
        pageAuto = findViewById(R.id.pageAuto)

        btnSelectFolder   = findViewById(R.id.btnSelectFolder)
        tvFolderPath      = findViewById(R.id.tvFolderPath)
        layoutModeChoice  = findViewById(R.id.layoutModeChoice)
        btnModeAuto       = findViewById(R.id.btnModeAuto)
        btnModeManual     = findViewById(R.id.btnModeManual)
        layoutAutoMode    = findViewById(R.id.layoutAutoMode)
        tvDetectedName    = findViewById(R.id.tvDetectedName)
        btnFetchNow       = findViewById(R.id.btnFetchNow)
        btnOpenSubsource  = findViewById(R.id.btnOpenSubsource)
        btnCheckDownloads = findViewById(R.id.btnCheckDownloads)
        layoutManualMode  = findViewById(R.id.layoutManualMode)
        btnSelectZip      = findViewById(R.id.btnSelectZip)
        tvZipPath         = findViewById(R.id.tvZipPath)
        btnRun            = findViewById(R.id.btnRun)
        layoutStatus      = findViewById(R.id.layoutStatus)
        progressBar       = findViewById(R.id.progressBar)
        tvResult          = findViewById(R.id.tvResult)

        bt4gSearchInput         = findViewById(R.id.bt4gSearchInput)
        bt4gSearchBtn           = findViewById(R.id.bt4gSearchBtn)
        bt4gProgressBar         = findViewById(R.id.bt4gProgressBar)
        bt4gStatusText          = findViewById(R.id.bt4gStatusText)
        bt4gWebView             = findViewById(R.id.bt4gWebView)
        subsWebView             = findViewById(R.id.subsWebView)
        subsBrowserLabel        = findViewById(R.id.subsBrowserLabel)
        bt4gTopSpacer           = findViewById(R.id.bt4gTopSpacer)
        bt4gBottomSpacer        = findViewById(R.id.bt4gBottomSpacer)
        bt4gDomainInput         = findViewById(R.id.bt4gDomainInput)
        bt4gDomainSaveBtn       = findViewById(R.id.bt4gDomainSaveBtn)
        bt4gSearchPatternInput  = findViewById(R.id.bt4gSearchPatternInput)
        bt4gMagnetSelectorInput = findViewById(R.id.bt4gMagnetSelectorInput)
        bt4gSiteLabel           = findViewById(R.id.bt4gSiteLabel)
        bt4gSiteDropdownBtn     = findViewById(R.id.bt4gSiteDropdownBtn)
        bt4gAddSiteBtn          = findViewById(R.id.bt4gAddSiteBtn)
        bt4gAddStepBtn          = findViewById(R.id.bt4gAddStepBtn)
        bt4gSettingsCard        = findViewById(R.id.bt4gSettingsCard)
        bt4gSettingsBody        = findViewById(R.id.bt4gSettingsBody)
        bt4gSettingsToggle      = findViewById(R.id.bt4gSettingsToggle)

        ytsSearchInput  = findViewById(R.id.ytsSearchInput)
        ytsSearchBtn    = findViewById(R.id.ytsSearchBtn)
        ytsProgressBar  = findViewById(R.id.ytsProgressBar)
        ytsStatusText   = findViewById(R.id.ytsStatusText)
        ytsWebView      = findViewById(R.id.ytsWebView)
        ytsTopSpacer    = findViewById(R.id.ytsTopSpacer)
        ytsBottomSpacer = findViewById(R.id.ytsBottomSpacer)
        ytsQualityRow   = findViewById(R.id.ytsQualityRow)
        ytsBtn1080      = findViewById(R.id.ytsBtn1080)
        ytsBtn2160      = findViewById(R.id.ytsBtn2160)
        ytsDomainInput          = findViewById(R.id.ytsDomainInput)
        ytsDomainSaveBtn        = findViewById(R.id.ytsDomainSaveBtn)
        ytsSearchPatternInput   = findViewById(R.id.ytsSearchPatternInput)
        ytsTorrentSelectorInput = findViewById(R.id.ytsTorrentSelectorInput)

        autoWatchFolderBtn   = findViewById(R.id.autoWatchFolderBtn)
        autoWatchFolderLabel = findViewById(R.id.autoWatchFolderLabel)
        autoToggleBtn        = findViewById(R.id.autoToggleBtn)
        autoStatusIcon       = findViewById(R.id.autoStatusIcon)
        autoLogView          = findViewById(R.id.autoLogView)
        autoLogScroll        = findViewById(R.id.autoLogScroll)
        autoStatsText        = findViewById(R.id.autoStatsText)
        autoClearLogBtn      = findViewById(R.id.autoClearLogBtn)
    }

    // ── Notifications ────────────────────────────────────────────────
    private fun createNotifChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(NOTIF_CHANNEL, "Auto Subs",
                NotificationManager.IMPORTANCE_DEFAULT).apply {
                description = "إشعارات تحميل الترجمة التلقائي"
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
    }

    private fun requestNotifPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ActivityCompat.checkSelfPermission(this, android.Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 101)
        }
    }

    private fun sendNotif(title: String, text: String, id: Int = 200) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            ActivityCompat.checkSelfPermission(this, android.Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED) return
        val n = NotificationCompat.Builder(this, NOTIF_CHANNEL)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title).setContentText(text)
            .setAutoCancel(true).setPriority(NotificationCompat.PRIORITY_DEFAULT).build()
        NotificationManagerCompat.from(this).notify(id, n)
    }

    // ── Swipe ────────────────────────────────────────────────────────
    private fun setupSwipe() {
        gestureDetector = GestureDetectorCompat(this,
            object : GestureDetector.SimpleOnGestureListener() {
                override fun onFling(e1: MotionEvent?, e2: MotionEvent,
                                     vx: Float, vy: Float): Boolean {
                    val dx = e2.x - (e1?.x ?: e2.x)
                    if (Math.abs(dx) > 250 && Math.abs(vx) > 250) {
                        if (dx < 0) switchTab((currentTab + 1).coerceAtMost(3))
                        else        switchTab((currentTab - 1).coerceAtLeast(0))
                        return true
                    }
                    return false
                }
            })
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        gestureDetector.onTouchEvent(ev)
        return super.dispatchTouchEvent(ev)
    }

    // ── Tabs ─────────────────────────────────────────────────────────
    private fun setupTabs() {
        tabSrt.setOnClickListener  { switchTab(0) }
        tabBt4g.setOnClickListener { switchTab(1) }
        tabYts.setOnClickListener  { switchTab(2) }
        tabAuto.setOnClickListener { switchTab(3) }
    }

    private fun switchTab(tab: Int) {
        currentTab = tab
        pageSrt.visibility  = if (tab == 0) View.VISIBLE else View.GONE
        pageBt4g.visibility = if (tab == 1) View.VISIBLE else View.GONE
        pageYts.visibility  = if (tab == 2) View.VISIBLE else View.GONE
        pageAuto.visibility = if (tab == 3) View.VISIBLE else View.GONE
        val accent   = getColor(R.color.color_accent)
        val subtitle = getColor(R.color.color_subtitle)
        val bg       = getColor(R.color.color_bg)
        val card     = getColor(R.color.color_card)
        listOf(tabSrt to 0, tabBt4g to 1, tabYts to 2, tabAuto to 3).forEach { (tv, i) ->
            tv.setTextColor(if (tab == i) accent else subtitle)
            tv.setBackgroundColor(if (tab == i) bg else card)
        }
        if (tab == 1) pasteClipboard()
    }

    private fun pasteClipboard() {
        if (bt4gSearchInput.text.isNotEmpty()) return
        val clip = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        val text = clip.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString()?.trim()
            ?.takeIf { it.isNotBlank() } ?: return
        bt4gSearchInput.setText(text)
        bt4gSearchInput.setSelection(text.length)
        Toast.makeText(this, "📋 تم لصق: $text", Toast.LENGTH_SHORT).show()
    }

    // ═══════════════════════════════════════════════════════════════════
    //  SRT RENAMER TAB
    // ═══════════════════════════════════════════════════════════════════
    private fun setupSrt() {
        btnSelectFolder.setOnClickListener {
            folderLauncher.launch(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or
                         Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                         Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
            })
        }
        btnModeAuto.setOnClickListener   { switchSrtMode("auto")   }
        btnModeManual.setOnClickListener { switchSrtMode("manual") }
        btnFetchNow.setOnClickListener {
            val slug = detectedSlug
            val uri  = selectedFolderUri
            if (slug != null && uri != null) {
                layoutStatus.visibility = View.VISIBLE
                progressBar.visibility  = View.VISIBLE
                tvResult.text = "جاري جلب الترجمة..."
                btnFetchNow.isEnabled = false; btnFetchNow.alpha = 0.5f
                val parsed = ParsedName(slug, tvDetectedName.text.toString().removePrefix("🎬  "), null, false)
                CoroutineScope(Dispatchers.Main).launch {
                    var zipBytes: ByteArray? = null
                    val urlList = buildSubSourceUrls(parsed)
                    zipBytes = suspendWebViewFetch(urlList, parsed.friendly)
                    withContext(Dispatchers.Main) {
                        btnFetchNow.isEnabled = true; btnFetchNow.alpha = 1f
                        if (zipBytes == null) {
                            showStatus(false, "❌ ما لقيتش ترجمة\nجرب يدويًا من زر Subsource")
                        } else {
                            val srts = unzipSrts(zipBytes)
                            if (srts.isEmpty()) {
                                showStatus(false, "❌ الـ ZIP فاضي من الترجمات")
                            } else {
                                selectedZipUri = null
                                // write directly
                                CoroutineScope(Dispatchers.IO).launch {
                                    val videos = filesInFolder(uri).filter {
                                        it.name.substringAfterLast(".").lowercase() in VIDEO_EXTS }
                                    val folderDoc = DocumentFile.fromTreeUri(this@MainActivity, uri)!!
                                    var count = 0
                                    for (video in videos) {
                                        val base = video.name.substringBeforeLast(".")
                                        val sm2 = Regex("S(\\d+)E(\\d+)", RegexOption.IGNORE_CASE).find(video.name)
                                        val srt = if (sm2 != null) {
                                            val (s, e) = sm2.destructured
                                            srts.firstOrNull { Regex("S${s}E${e}", RegexOption.IGNORE_CASE).containsMatchIn(it.name) }
                                                ?: srts.first()
                                        } else srts.first()
                                        writeFile(folderDoc, uri, "$base.srt", srt.content, video.parentDocId)
                                        count++
                                        if (count >= 1 && sm2 == null) break // one movie only
                                    }
                                    withContext(Dispatchers.Main) {
                                        showStatus(true, "✅ تم!\n$count ترجمة اتحفظت بجانب الفيديو")
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        btnOpenSubsource.setOnClickListener {
            detectedSlug?.let { slug ->
                wentToSubsource = true
                startActivity(Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://subsource.net/subtitles/$slug")))
            }
        }
        btnCheckDownloads.setOnClickListener { openDownloadsPicker() }
        btnSelectZip.setOnClickListener {
            zipLauncher.launch(Intent(Intent.ACTION_GET_CONTENT).apply {
                type = "*/*"; addCategory(Intent.CATEGORY_OPENABLE)
                putExtra(Intent.EXTRA_MIME_TYPES, arrayOf(
                    "application/zip","application/x-zip-compressed","application/octet-stream"))
            })
        }
        btnRun.setOnClickListener { processFiles() }
    }

    private fun onFolderSelected(uri: Uri) {
        val rawName = uri.lastPathSegment?.substringAfter(":")?.substringAfterLast("/") ?: "?"
        tvFolderPath.text = rawName
        tvFolderPath.setTextColor(getColor(R.color.color_success))
        val (slug, friendly) = slugAndName(rawName)
        detectedSlug = slug
        tvDetectedName.text = "🎬  $friendly"
        layoutModeChoice.visibility = View.VISIBLE
        layoutAutoMode.visibility   = View.GONE
        layoutManualMode.visibility = View.GONE
        btnRun.visibility           = View.GONE
        layoutStatus.visibility     = View.GONE
        currentMode = "none"
    }

    private fun switchSrtMode(mode: String) {
        currentMode = mode
        layoutAutoMode.visibility   = if (mode == "auto")   View.VISIBLE else View.GONE
        layoutManualMode.visibility = if (mode == "manual") View.VISIBLE else View.GONE
        btnRun.visibility           = if (mode == "manual") View.VISIBLE else View.GONE
        if (mode == "manual") { btnRun.isEnabled = false; btnRun.alpha = 0.5f }
        val bg    = getColor(R.color.color_bg)
        val white = getColor(R.color.color_white)
        btnModeAuto.backgroundTintList   = ContextCompat.getColorStateList(this,
            if (mode == "auto")   R.color.color_accent else R.color.color_card)
        btnModeAuto.setTextColor(if (mode == "auto") bg else white)
        btnModeManual.backgroundTintList = ContextCompat.getColorStateList(this,
            if (mode == "manual") R.color.color_accent else R.color.color_card)
        btnModeManual.setTextColor(if (mode == "manual") bg else white)
    }

    private fun openDownloadsPicker() {
        zipLauncher.launch(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            type = "*/*"; addCategory(Intent.CATEGORY_OPENABLE)
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf(
                "application/zip","application/x-zip-compressed","application/octet-stream",
                "application/x-subrip","text/plain"))
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                putExtra(DocumentsContract.EXTRA_INITIAL_URI,
                    Uri.parse("content://com.android.providers.downloads.documents/root/downloads"))
        })
    }

    private fun checkRunReady() {
        val ok = selectedFolderUri != null && selectedZipUri != null
        btnRun.isEnabled = ok; btnRun.alpha = if (ok) 1f else 0.5f
    }

    private fun processFiles() {
        val folderUri = selectedFolderUri ?: return
        val zipUri    = selectedZipUri    ?: return
        layoutStatus.visibility = View.VISIBLE
        progressBar.visibility  = View.VISIBLE
        tvResult.text = "Processing..."
        setButtonsEnabled(false)
        CoroutineScope(Dispatchers.IO).launch {
            val res = try {
                val srts = extractSrtsFromUri(zipUri)
                    ?: return@launch withContext(Dispatchers.Main) {
                        showStatus(false, "Cannot open ZIP"); setButtonsEnabled(true) }
                if (srts.isEmpty()) ProcessResult(false, "No SRT files in ZIP")
                else renameAndPlace(folderUri, srts)
            } catch (e: Exception) { ProcessResult(false, "Error:\n${e.message}") }
            withContext(Dispatchers.Main) { showStatus(res.success, res.message); setButtonsEnabled(true) }
        }
    }

    private fun renameAndPlace(folderUri: Uri, srts: List<ExtFile>): ProcessResult {
        val videos = filesInFolder(folderUri).filter {
            it.name.substringAfterLast(".").lowercase() in VIDEO_EXTS }
        if (videos.isEmpty())
            return ProcessResult(false, "No video files in folder.\nCheck selected folder.")
        val folderDoc = DocumentFile.fromTreeUri(this, folderUri)!!
        var count = 0
        for (video in videos) {
            val base = video.name.substringBeforeLast(".")
            val sm = Regex("S(\\d+)E(\\d+)", RegexOption.IGNORE_CASE).find(video.name)
            if (sm != null) {
                val (s, e) = sm.destructured
                (srts.firstOrNull { Regex("S${s}E${e}", RegexOption.IGNORE_CASE).containsMatchIn(it.name) }
                    ?: srts.firstOrNull())
                    ?.let { writeFile(folderDoc, folderUri, "$base.srt", it.content, video.parentDocId); count++ }
                continue
            }
            val yr = Regex("(19|20)\\d{2}").find(video.name)?.value
            if (yr != null) {
                srts.firstOrNull { srt ->
                    Regex("(19|20)\\d{2}").find(srt.name)?.value == yr &&
                    similarity(cleanTitle(video.name), cleanTitle(srt.name)) >= 0.5
                }?.let { writeFile(folderDoc, folderUri, "$base.srt", it.content, video.parentDocId); count++ }
            }
        }
        // fallback: pair first srt with first video
        if (count == 0 && srts.isNotEmpty()) {
            val base = videos.first().name.substringBeforeLast(".")
            writeFile(folderDoc, folderUri, "$base.srt", srts.first().content, videos.first().parentDocId)
            count = 1
        }
        return if (count > 0) ProcessResult(true, "Done! ✓\n$count subtitle(s) renamed & placed")
               else ProcessResult(false, "No matching pairs found")
    }

    // ═══════════════════════════════════════════════════════════════════
    //  AUTO MODE TAB
    // ═══════════════════════════════════════════════════════════════════
    private fun setupAutoMode() {
        autoWatchFolderBtn.setOnClickListener {
            autoFolderLauncher.launch(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).apply {
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or
                         Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                         Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
            })
        }
        autoToggleBtn.setOnClickListener { if (autoRunning) stopAuto() else startAuto() }
        autoClearLogBtn.setOnClickListener { autoLogSB.clear(); autoLogView.text = "" }
    }

    fun startAuto() {
        if (autoWatchFolderUri == null) {
            Toast.makeText(this, "اختار المجلد الأول", Toast.LENGTH_SHORT).show()
            return
        }
        autoRunning = true
        savePrefs()
        autoToggleBtn.text = "⏹ إيقاف المراقبة"
        autoToggleBtn.backgroundTintList =
            ContextCompat.getColorStateList(this, R.color.color_error)
        autoStatusIcon.text = "🟢 يراقب..."
        autoLog("═══════════════════════════")
        autoLog("🚀 بدأت المراقبة")
        autoLog("📁 ${folderDisplayName(autoWatchFolderUri!!)}")

        // شغّل الـ ForegroundService عشان التطبيق يفضل شغال في الخلفية
        val svcIntent = Intent(this, WatchService::class.java)
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O)
            startForegroundService(svcIntent)
        else
            startService(svcIntent)

        startWatchLoop()
    }

    private fun stopAuto() {
        autoRunning = false
        autoWatchJob?.cancel(); autoWatchJob = null
        savePrefs()
        autoToggleBtn.text = "▶ ابدأ المراقبة"
        autoToggleBtn.backgroundTintList =
            ContextCompat.getColorStateList(this, R.color.color_accent)
        autoStatusIcon.text = "⚪ متوقف"
        autoLog("⏹ توقفت المراقبة")

        // أوقف الـ ForegroundService
        stopService(Intent(this, WatchService::class.java))
    }

    // ── Folder watch loop ────────────────────────────────────────────
    private fun startWatchLoop() {
        val uri = autoWatchFolderUri ?: return

        autoWatchJob = CoroutineScope(Dispatchers.IO).launch {

            // ── STEP 1: process whatever is ALREADY in the folder ────
            val existing = filesInFolder(uri)
                .filter { it.name.substringAfterLast(".").lowercase() in VIDEO_EXTS }

            withContext(Dispatchers.Main) {
                autoLog("📂 ${existing.size} ملف موجود — هشتغل عليهم كلهم")
            }

            for (file in existing) {
                if (!autoRunning) return@launch
                // skip if subtitle already exists next to it
                val srtName = file.name.substringBeforeLast(".") + ".srt"
                val alreadyHasSub = filesInFolder(uri).any { it.name == srtName }
                if (alreadyHasSub) {
                    withContext(Dispatchers.Main) { autoLog("⏭ ${file.name} — ترجمة موجودة") }
                    processedNames.add(file.name)
                    continue
                }
                processedNames.add(file.name)
                processVideoFile(file, uri)
            }

            withContext(Dispatchers.Main) { autoLog("👁 الآن أراقب الملفات الجديدة...") }

            // ── STEP 2: poll for NEW files every 10 sec ──────────────
            while (autoRunning) {
                delay(10_000)
                try {
                    val current = filesInFolder(uri)
                        .filter { it.name.substringAfterLast(".").lowercase() in VIDEO_EXTS }

                    for (file in current) {
                        if (file.name !in processedNames) {
                            processedNames.add(file.name)
                            withContext(Dispatchers.Main) { autoLog("\n🆕 ملف جديد: ${file.name}") }
                            delay(3_000) // brief wait so file is fully written

                            // ── تأكد إن الـ Activity موجودة وتاب Auto ظاهر ──
                            // الـ WebView لازم يكون visible علشان يشتغل صح
                            withContext(Dispatchers.Main) {
                                if (!isActivityVisible || currentTab != 3) {
                                    val wakeIntent = Intent(this@MainActivity, MainActivity::class.java).apply {
                                        action = ACTION_WAKE_AUTO
                                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
                                    }
                                    startActivity(wakeIntent)
                                    autoLog("⚡ فتح Auto tab لبدء الترجمة...")
                                }
                            }
                            // انتظر شوية تنتهي الـ Activity من الـ resume
                            delay(800)

                            processVideoFile(file, uri)
                        }
                    }
                } catch (_: Exception) {}
            }
        }
    }

    // ── Process one video: fetch subtitle from SubSource ────────────
    private suspend fun processVideoFile(videoFile: FileEntry, folderUri: Uri) {
        val fileName = videoFile.name
        withContext(Dispatchers.Main) {
            autoLog("\n🔍 أجهّز ترجمة لـ: $fileName")
            autoStatusIcon.text = "⏳ جاري..."
        }

        val parsed = parseName(fileName)
        withContext(Dispatchers.Main) { autoLog("🎬 ${parsed.friendly}") }

        // API-first fetch (bypasses Cloudflare), WebView only as last resort
        val urls = buildSubSourceUrls(parsed)
        withContext(Dispatchers.Main) { autoLog("   🌐 ${urls.size} رابط للمحاولة عبر المتصفح") }
        val zipBytes = suspendWebViewFetch(urls, parsed.friendly)


        if (zipBytes == null) {
            withContext(Dispatchers.Main) {
                autoLog("❌ ما لقيتش ترجمة لـ: ${parsed.friendly}")
                autoFailCount++; updateStats()
            }
            sendNotif("⚠️ Auto Subs", "ما لقيتش ترجمة: ${parsed.friendly}",
                300 + autoFailCount)
            return
        }

        val srts = unzipSrts(zipBytes)
        if (srts.isEmpty()) {
            withContext(Dispatchers.Main) { autoLog("❌ الـ ZIP فاضي من الترجمات") }
            return
        }
        withContext(Dispatchers.Main) {
            autoLog("📦 ${srts.size} ترجمة في الـ ZIP:")
            srts.forEach { autoLog("   • ${it.name}") }
        }

        // Write SRT file next to the video
        val folderDoc = DocumentFile.fromTreeUri(this, folderUri)!!
        val base  = fileName.substringBeforeLast(".")
        val sm    = Regex("S(\\d+)E(\\d+)", RegexOption.IGNORE_CASE).find(fileName)
        val srt   = if (sm != null) {
            val (s, e) = sm.destructured
            val matched = srts.firstOrNull { Regex("S${s}E${e}", RegexOption.IGNORE_CASE).containsMatchIn(it.name) }
            if (matched != null) {
                withContext(Dispatchers.Main) { autoLog("🎯 تطابق S${s}E${e}: ${matched.name}") }
                matched
            } else {
                withContext(Dispatchers.Main) { autoLog("⚠️ مش لاقي S${s}E${e} — هياخد أول ترجمة") }
                srts.first()
            }
        } else srts.first()

        withContext(Dispatchers.Main) { autoLog("✏️  rename: $base.srt ← ${srt.name}") }
        writeFile(folderDoc, folderUri, "$base.srt", srt.content, videoFile.parentDocId)

        withContext(Dispatchers.Main) {
            autoLog("✅ تم حفظ: $base.srt")
            autoSuccessCount++; updateStats()
            autoStatusIcon.text = "🟢 يراقب..."
        }
        sendNotif("✅ Auto Subs — جاهز!", "ترجمة: ${parsed.friendly}")
    }

    // ── SubSource scraper ────────────────────────────────────────────
    data class ParsedName(
        val slug     : String,
        val friendly : String,
        val season   : Int?,
        val isEpisode: Boolean
    )

    // Common release-group noise tokens to strip before building slug/title
    private val JUNK_TOKENS = Regex(
        "\\b(bluray|blu[.-]ray|bdrip|brrip|webrip|web[.-]dl|webdl|hdtv|dvdrip|dvd|" +
        "hdrip|hdr|sdr|dv|extended|repack|proper|internal|limited|" +
        "xvid|x264|x265|h264|h265|hevc|avc|" +
        "aac|ac3|dts|truehd|atmos|flac|mp3|" +
        "1080p|720p|480p|2160p|4k|uhd|" +
        "multi|dubbed|subbed|arabic|english|hindi|" +
        "yts|yify|rarbg|ettv|eztv|pahe|" +
        "season|episode|complete)\\b",
        RegexOption.IGNORE_CASE)

    private fun cleanForSearch(raw: String): String =
        raw.replace(Regex("[._\\-\\[\\]()]"), " ")
            .let { JUNK_TOKENS.replace(it, " ") }
            .replace(Regex("\\s+"), " ").trim()

    private fun parseName(fileName: String): ParsedName {
        // Use slugAndName (same logic as SRT tab) as the primary slug builder,
        // then layer on episode/season detection.
        val sm = Regex("S(\\d+)E\\d+", RegexOption.IGNORE_CASE).find(fileName)
        if (sm != null) {
            val sNum = sm.groupValues[1].toIntOrNull()
            // Get clean title using slugAndName on the part before SxxExx
            val namePart = fileName.substring(0, sm.range.first)
            val (slugBase, friendlyBase) = slugAndName(namePart.ifBlank { fileName })
            // slugAndName may have appended a year if the series name contains one — strip it
            val slugClean = slugBase.replace(Regex("-\\d{4}$"), "").trim('-')
            return ParsedName(slugClean, friendlyBase.replace(Regex("\\s*\\(\\d{4}\\)$"), "").trim(), sNum, true)
        }
        // Movie — slugAndName handles year extraction perfectly
        val (slug, friendly) = slugAndName(fileName)
        return ParsedName(slug, friendly, null, false)
    }

    private fun buildSubSourceUrls(p: ParsedName): List<String> {
        // Build web page URL specs for WebView navigation.
        // Mirrors Python build_urls() exactly.
        val titleOnly = p.friendly.replace(Regex("\\(\\d{4}\\)$"), "").trim()
        val slugNoArticle = p.slug
            .removePrefix("the-").removePrefix("a-").removePrefix("an-")
            .trim('-')

        return if (p.isEpisode && p.season != null) {
            // Series: slug (with year), slug without year, no-article, search
            val yr = Regex("-(\\d{4})$").find(p.slug)?.groupValues?.get(1)
            val slugNoYear = if (yr != null) p.slug.removeSuffix("-$yr") else p.slug
            listOf(
                "WEB:${p.slug}:${p.season}",
                "WEB:${slugNoYear}:${p.season}",
                "WEB:$slugNoArticle:${p.season}",
                "SEARCH:$titleOnly:${p.season}"
            ).distinct()
        } else {
            // Movie: slug (with year), without year, no-article, search
            val yr = Regex("-(\\d{4})$").find(p.slug)?.groupValues?.get(1)
            val slugNoYear = if (yr != null) p.slug.removeSuffix("-$yr") else p.slug
            listOf(
                "WEB:${p.slug}:0",
                "WEB:${slugNoYear}:0",
                "WEB:$slugNoArticle:0",
                "SEARCH:$titleOnly:0"
            ).distinct()
        }
    }

    // ─── SubSource WebView fetcher — mirrors Python chrome_get_subtitle_links flow ──
    // WebView is PRIMARY (not fallback). API always fails without real browser cookies.
    // Flow: open movie page → get subtitle links → open best subtitle → get download URL → fetch ZIP

    private suspend fun suspendWebViewFetch(
        urls: List<String>,
        label: String
    ): ByteArray? {
        subsLog("🔍 جاري البحث عن ترجمة: $label")
        subsLog("   🌐 فتح المتصفح مباشرةً...")

        // Build page URLs from specs — same logic as buildWebViewFallbackUrls
        val webUrls = buildWebViewFallbackUrls(urls)
        if (webUrls.isEmpty()) { subsLog("   ❌ لا روابط للمحاولة"); return null }

        return suspendCancellableCoroutine { cont ->
            runOnUiThread {
                subsUrlQueue    = ArrayDeque(webUrls)
                subsCfRetries   = 0
                subsCurrentPage = null
                subsLabel       = label
                subsShowBrowser(true)   // show immediately — WebView needs to be visible to render
                subsCallback    = { bytes ->
                    subsCallback = null
                    subsShowBrowser(false)
                    if (cont.isActive) cont.resume(bytes)
                }
                subsAdvance()
            }
        }
    }

    // Build real subsource.net page URLs from WEB:/SEARCH: specs
    private fun buildWebViewFallbackUrls(specs: List<String>): List<String> {
        val out  = mutableListOf<String>()
        val seen = mutableSetOf<String>()
        for (spec in specs) {
            when {
                spec.startsWith("WEB:") -> {
                    val parts  = spec.removePrefix("WEB:").split(":")
                    val slug   = parts.getOrNull(0) ?: continue
                    val season = parts.getOrNull(1)?.toIntOrNull() ?: 0
                    val url    = if (season > 0)
                        "https://subsource.net/subtitles/$slug/season-$season"
                    else
                        "https://subsource.net/subtitles/$slug"
                    if (seen.add(url)) out.add(url)
                }
                spec.startsWith("SEARCH:") -> {
                    val parts = spec.removePrefix("SEARCH:").split(":")
                    val query = parts.getOrNull(0) ?: ""
                    if (query.isNotBlank()) {
                        val url = "https://subsource.net/search?q=${Uri.encode(query)}"
                        if (seen.add(url)) out.add(url)
                    }
                }
                // Legacy API_ specs (keep for SRT tab compatibility)
                spec.startsWith("API_MOVIE:") -> {
                    val parts  = spec.removePrefix("API_MOVIE:").split(":")
                    val slug   = parts.getOrNull(0) ?: continue
                    val season = parts.getOrNull(1)?.toIntOrNull() ?: 0
                    val url    = if (season > 0)
                        "https://subsource.net/subtitles/$slug/season-$season"
                    else
                        "https://subsource.net/subtitles/$slug"
                    if (seen.add(url)) out.add(url)
                }
                spec.startsWith("API_SEARCH:") -> {
                    val parts = spec.removePrefix("API_SEARCH:").split(":")
                    val query = parts.getOrNull(0) ?: ""
                    if (query.isNotBlank()) {
                        val url = "https://subsource.net/search?q=${Uri.encode(query)}"
                        if (seen.add(url)) out.add(url)
                    }
                }
            }
        }
        return out
    }

    // tryApiSpec removed — WebView is primary

    // Build download URL and fetch ZIP bytes
    private fun downloadSubSourceZip(subId: String, release: String, movieSlug: String): ByteArray? {
        val referer = "https://subsource.net/subtitles/$movieSlug"
        val hdrs = mapOf("Accept" to "application/zip,application/octet-stream,*/*",
                         "Origin" to "https://subsource.net")
        // Try multiple known SubSource download URL patterns
        val candidates = listOf(
            "https://api.subsource.net/api/downloadSub/$subId",
            "https://subsource.net/api/downloadSub/$subId",
            "https://api.subsource.net/api/downloadSub/${subId}/${Uri.encode(release)}",
            "https://subsource.net/api/download/$subId"
        )
        for (url in candidates) {
            val bytes = httpBytes(url, referer, headers = hdrs)
            if (bytes != null && bytes.size > 100) {
                subsLog("   ✅ تحميل نجح من: $url (${bytes.size/1024} KB)")
                return bytes
            }
        }
        subsLog("   ❌ فشل التحميل من كل الروابط (subId=$subId)")
        return null
    }

    // Simple HTTP GET returning response body as string
    private fun apiGet(url: String, referer: String = "https://subsource.net/"): String? = try {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.setRequestProperty("User-Agent",
            "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36")
        conn.setRequestProperty("Accept", "application/json,*/*")
        conn.setRequestProperty("Referer", referer)
        conn.setRequestProperty("Origin", "https://subsource.net")
        conn.connectTimeout = 20_000; conn.readTimeout = 20_000
        val code = conn.responseCode
        if (code in 200..299)
            conn.inputStream.bufferedReader().readText()
        else { subsLog("   ⚠️ HTTP $code لـ $url"); null }
    } catch (e: Exception) { subsLog("   ❌ استثناء: ${e.message}"); null }

    // ─── httpBytes — HTTP downloader with optional extra headers ──────────
    private fun httpBytes(
        url: String, referer: String,
        cookies: String = "",
        headers: Map<String, String> = emptyMap()
    ): ByteArray? = try {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.setRequestProperty("User-Agent",
            "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36")
        conn.setRequestProperty("Referer", referer)
        conn.setRequestProperty("Origin", "https://subsource.net")
        conn.setRequestProperty("Accept", "application/zip,application/octet-stream,*/*")
        if (cookies.isNotEmpty()) conn.setRequestProperty("Cookie", cookies)
        headers.forEach { (k, v) -> conn.setRequestProperty(k, v) }
        conn.instanceFollowRedirects = true
        conn.connectTimeout = 25_000; conn.readTimeout = 25_000
        if (conn.responseCode in 200..299) conn.inputStream.readBytes() else null
    } catch (_: Exception) { null }

    // ─── subsLog — writes to autoLog when available, else silently ────────
    private fun subsLog(msg: String) {
        runOnUiThread {
            try { autoLog(msg) } catch (_: Exception) {}
        }
    }

    // ─── setupSubsWebView — hidden browser, only used as CF fallback ──────
    @SuppressLint("SetJavaScriptEnabled")
    private fun setupSubsWebView() {
        CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(subsWebView, true)
        }
        subsWebView.settings.apply {
            javaScriptEnabled  = true
            domStorageEnabled  = true
            databaseEnabled    = true
            userAgentString    = "Mozilla/5.0 (Linux; Android 13; Pixel 7) " +
                "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"
        }
        subsWebView.addJavascriptInterface(object {
            @JavascriptInterface
            fun onSubLinks(json: String) = runOnUiThread { subsHandleLinks(json) }
            @JavascriptInterface
            fun onDownloadUrl(url: String, referer: String) = runOnUiThread { subsStartDownload(url, referer) }
            @JavascriptInterface
            fun onNoLinks() = runOnUiThread {
                subsLog("   ⚠️ لا روابط — التالي")
                subsAdvance()
            }
        }, "SubsBridge")

        subsWebView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, req: WebResourceRequest): Boolean {
                val u = req.url.toString()
                if (u.endsWith(".zip", true) ||
                    (u.contains("download", true) && u.contains("subsource"))) {
                    subsStartDownload(u, subsCurrentPage ?: "https://subsource.net")
                    return true
                }
                return false
            }
            override fun onPageFinished(view: WebView, url: String) {
                CookieManager.getInstance().flush()
                view.evaluateJavascript("""
                    (function(){
                        var t = document.title || '';
                        var b = document.body ? document.body.innerHTML : '';
                        return (t.toLowerCase().includes('just a moment') ||
                                t.toLowerCase().includes('checking') ||
                                b.includes('cf-browser-verification') ||
                                b.includes('challenge-form') ||
                                !!document.querySelector('#challenge-form,#cf-challenge-running')) ? 'cf' : 'ok';
                    })()""".trimIndent()) { res ->
                    if (res?.trim('"') == "cf") {
                        subsCfRetries++
                        subsShowBrowser(true)   // show now so CF challenge can render
                        if (subsCfRetries <= 12) {
                            subsLog("   🔐 Cloudflare ($subsCfRetries/12) — انتظار...")
                            // Simulate human interaction: scroll + wait longer
                            val delay = if (subsCfRetries < 4) 3000L else 5000L
                            subsWebView.postDelayed({
                                view.evaluateJavascript(
                                    "window.scrollTo(0, document.body.scrollHeight/2);", null)
                            }, delay)
                        } else {
                            subsLog("   ⛔ Cloudflare لم يُحل — التالي")
                            subsCfRetries = 0; subsAdvance()
                        }
                        return@evaluateJavascript
                    }
                    subsCfRetries = 0
                    // Wait 2.5s for React/Next.js to finish rendering before scraping
                    view.postDelayed({ subsScrapePage(view, url) }, 1000)
                }
            }
        }
    }

    private fun subsScrapePage(view: WebView, url: String) {
        // /subtitle/xxx     → individual sub detail page  → find download button/URL
        // /subtitles/xxx    → movie/season listing page   → find subtitle links (React)
        // /search?q=xxx     → search results              → find subtitle links (React)
        val isDetailPage = url.contains("/subtitle/") && !url.contains("/subtitles/")

        val js = if (isDetailPage) """
            (function(){
                var attempts = 0;
                function findDl() {
                    attempts++;
                    // 1) Direct download link (API pattern)
                    var btn = document.querySelector('a[href*="downloadSub"]')
                           || document.querySelector('a[href*="api.subsource"][href*="download"]')
                           || document.querySelector('a[href*="/subtitle/download/"]')
                           || document.querySelector('a[href$=".zip"]')
                           || document.querySelector('a[download]')
                           || document.querySelector('a[href*="/dl/"]');
                    if (btn && btn.href) {
                        SubsBridge.onDownloadUrl(btn.href, window.location.href);
                        return;
                    }
                    // 2) Look for onclick handler that contains a download URL
                    var allAs = document.querySelectorAll('a,button');
                    for (var i = 0; i < allAs.length; i++) {
                        var el = allAs[i];
                        var oc = el.getAttribute('onclick') || '';
                        var m = oc.match(/['"](https?:\/\/[^'"]*download[^'"]*)['"]/i);
                        if (m) { SubsBridge.onDownloadUrl(m[1], window.location.href); return; }
                    }
                    // 3) Check for __NEXT_DATA__ JSON which may contain download URL
                    var nd = document.getElementById('__NEXT_DATA__');
                    if (nd) {
                        try {
                            var data = JSON.parse(nd.textContent);
                            var str = JSON.stringify(data);
                            var urlMatch = str.match(/"(https?:\/\/[^"]*downloadSub[^"]*)"/);
                            if (!urlMatch) urlMatch = str.match(/"(https?:\/\/api\.subsource\.net[^"]*download[^"]*)"/);
                            if (urlMatch) { SubsBridge.onDownloadUrl(urlMatch[1], window.location.href); return; }
                            // Also extract subId + release from page data
                            var sidM = str.match(/"subId"\s*:\s*"([^"]+)"/);
                            var relM = str.match(/"release"\s*:\s*"([^"]+)"/);
                            if (sidM) {
                                var dlUrl = 'https://api.subsource.net/api/downloadSub/' + sidM[1];
                                SubsBridge.onDownloadUrl(dlUrl, window.location.href);
                                return;
                            }
                        } catch(e) {}
                    }
                    if (attempts < 10) {
                        setTimeout(findDl, 800);
                    } else {
                        SubsBridge.onNoLinks();
                    }
                }
                findDl();
            })()""".trimIndent()
        else """
            (function(){
                // React/Next.js renders async — poll up to 10 seconds
                var attempts = 0;
                function scrape() {
                    attempts++;
                    window.scrollTo(0, document.body.scrollHeight);
                    setTimeout(function(){ window.scrollTo(0, 0); }, 200);

                    // Try direct links first
                    var links = Array.from(document.querySelectorAll('a[href^="/subtitle/"]'))
                                     .map(function(a){ return a.href; });
                    var arabic = links.filter(function(h){ return h.toLowerCase().includes('/arabic/') || h.toLowerCase().includes('arabic'); });
                    var others = links.filter(function(h){ return !h.toLowerCase().includes('/arabic/') && !h.toLowerCase().includes('arabic'); });
                    var all = arabic.concat(others).filter(function(v,i,a){ return a.indexOf(v)===i; });

                    if (all.length > 0) {
                        SubsBridge.onSubLinks(JSON.stringify(all.slice(0, 10)));
                        return;
                    }

                    // Try __NEXT_DATA__ for SSR-rendered subtitle list
                    var nd = document.getElementById('__NEXT_DATA__');
                    if (nd) {
                        try {
                            var data = JSON.parse(nd.textContent);
                            var subs = null;
                            // Walk the props tree looking for subtitle arrays
                            function findSubs(obj) {
                                if (!obj || typeof obj !== 'object') return;
                                if (Array.isArray(obj)) { obj.forEach(findSubs); return; }
                                if (obj.subId && obj.lang) { if (!subs) subs = []; subs.push(obj); return; }
                                Object.values(obj).forEach(findSubs);
                            }
                            findSubs(data);
                            if (subs && subs.length > 0) {
                                var hrefs = subs
                                    .filter(function(s){ return (s.lang||'').toLowerCase().includes('arab'); })
                                    .concat(subs)
                                    .filter(function(s,i,a){ return a.indexOf(s)===i; })
                                    .slice(0,10)
                                    .map(function(s){ return 'https://subsource.net/subtitle/' + s.subId; });
                                if (hrefs.length > 0) { SubsBridge.onSubLinks(JSON.stringify(hrefs)); return; }
                            }
                        } catch(e) {}
                    }

                    if (attempts < 10) {
                        setTimeout(scrape, 1000);
                    } else {
                        SubsBridge.onNoLinks();
                    }
                }
                scrape();
            })()""".trimIndent()
        view.evaluateJavascript(js, null)
    }

    private fun subsHandleLinks(json: String) {
        val links = try {
            val arr = org.json.JSONArray(json)
            (0 until arr.length()).map { arr.getString(it) }
        } catch (_: Exception) { emptyList() }
        if (links.isEmpty()) { subsAdvance(); return }

        // ── فرز: عربي أولاً ──────────────────────────────────────────
        val arabicLinks = links.filter { it.lowercase().contains("arabic") }
        val otherLinks  = links.filter { !it.lowercase().contains("arabic") }
        val sorted      = arabicLinks + otherLinks

        subsLog("   📑 ${links.size} ترجمة (${arabicLinks.size} عربي) — أفتح العربي أولاً")

        // باقي الروابط تتحمّل كاحتياط لو العربي فشل
        sorted.drop(1).reversed().forEach { subsUrlQueue.addFirst(it) }
        subsCurrentPage = sorted[0]; subsCfRetries = 0
        subsWebView.loadUrl(sorted[0])
    }

    private fun subsStartDownload(dlUrl: String, referer: String) {
        subsLog("   ⬇️ جاري التحميل...")
        val cookies = CookieManager.getInstance().getCookie("https://subsource.net") ?: ""
        CoroutineScope(Dispatchers.IO).launch {
            val bytes = httpBytes(dlUrl, referer, cookies)
            withContext(Dispatchers.Main) {
                if (bytes != null && bytes.size > 100) {
                    val srtsCheck = unzipSrts(bytes)
                    if (srtsCheck.isEmpty()) {
                        subsLog("   ⚠️ الـ ZIP فاضي من الترجمات — التالي")
                        subsAdvance()
                    } else {
                        subsLog("   ✅ تم تحميل ${bytes.size / 1024} KB")
                        subsShowBrowser(false)
                        subsCallback?.invoke(bytes)
                    }
                } else {
                    subsLog("   ⚠️ فشل التحميل — التالي")
                    subsAdvance()
                }
            }
        }
    }

    private fun subsShowBrowser(visible: Boolean) {
        val vis = if (visible) View.VISIBLE else View.GONE
        subsWebView.visibility      = vis
        subsBrowserLabel.visibility = vis
        if (visible) {
            // Ensure WebView fills the FrameLayout overlay
            val lp = subsWebView.layoutParams
            lp.height = android.view.ViewGroup.LayoutParams.MATCH_PARENT
            subsWebView.layoutParams = lp
            // Show current URL in the label
            val currentUrl = subsCurrentPage ?: ""
            subsBrowserLabel.text = "🌐 $currentUrl"
        } else {
            subsBrowserLabel.text = "🌐 متصفح SubSource (جاري حل Cloudflare...)"
        }
    }

    private fun subsAdvance() {
        val url = subsUrlQueue.removeFirstOrNull()
        if (url == null) {
            subsLog("⛔ استنفدت كل روابط المتصفح لـ: $subsLabel")
            subsShowBrowser(false)
            subsCallback?.invoke(null)
            return
        }
        subsLog("   🌐 $url")
        subsCurrentPage = url
        subsCfRetries   = 0
        // Always show browser — hidden WebViews don't render React/JS pages correctly
        subsWebView.bringToFront()
        subsShowBrowser(true)
        subsWebView.loadUrl(url)
    }

    private fun unzipSrts(bytes: ByteArray): List<ExtFile> {
        val out = mutableListOf<ExtFile>()
        return try {
            ZipInputStream(ByteArrayInputStream(bytes)).use { z ->
                var e = z.nextEntry
                while (e != null) {
                    if (!e.isDirectory &&
                        e.name.substringAfterLast(".").lowercase() in setOf("srt","ass","ssa","vtt"))
                        out.add(ExtFile(e.name.substringAfterLast("/"), z.readBytes()))
                    z.closeEntry(); e = z.nextEntry
                }
            }
            out
        } catch (_: Exception) { out }
    }

    // ── Log helpers ──────────────────────────────────────────────────
    private fun autoLog(msg: String) {
        autoLogSB.append("$msg\n")
        // keep max 200 lines
        val lines = autoLogSB.lines()
        if (lines.size > 200) {
            autoLogSB.clear()
            autoLogSB.append(lines.takeLast(150).joinToString("\n")).append("\n")
        }
        autoLogView.text = autoLogSB
        autoLogScroll.post { autoLogScroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun updateStats() {
        autoStatsText.text = "✅ نجح: $autoSuccessCount   ❌ فشل: $autoFailCount"
    }

    // ── Prefs ────────────────────────────────────────────────────────
    private fun savePrefs() {
        // Serialize sites to JSON string
        val sitesJson = buildString {
            append("[")
            bt4gSites.forEachIndexed { i, s ->
                if (i > 0) append(",")
                append("{\"name\":${org.json.JSONObject.quote(s.name)},")
                append("\"domain\":${org.json.JSONObject.quote(s.domain)},")
                append("\"pattern\":${org.json.JSONObject.quote(s.pattern)},")
                append("\"selector\":${org.json.JSONObject.quote(s.selector)},")
                // حفظ الخطوات كـ JSON array
                val stepsJson = "[" + s.steps.joinToString(",") { "\"${it.replace("\"","\\\"").replace("\\","\\\\") }\"" } + "]"
                append("\"steps\":$stepsJson}")
            }
            append("]")
        }
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
            .putString(KEY_WATCH_URI, autoWatchFolderUri?.toString())
            .putBoolean(KEY_AUTO_RUNNING, autoRunning)
            .putString(KEY_YTS_DOMAIN, ytsDomain)
            .putString(KEY_YTS_PATTERN, ytsSearchPattern)
            .putString(KEY_YTS_SELECTOR, ytsTorrentSelector)
            .putString(KEY_BT4G_DOMAIN, bt4gDomain)
            .putString(KEY_BT4G_PATTERN, bt4gSearchPattern)
            .putString(KEY_BT4G_SELECTOR, bt4gMagnetSelector)
            .putString(KEY_BT4G_SITES, sitesJson)
            .putInt(KEY_BT4G_SITE_IDX, bt4gCurrentSiteIndex)
            .apply()
    }

    private fun loadPrefs() {
        val p = getSharedPreferences(PREFS, MODE_PRIVATE)
        p.getString(KEY_WATCH_URI, null)?.let { s ->
            autoWatchFolderUri = Uri.parse(s)
            autoWatchFolderLabel.text = "📁 ${folderDisplayName(autoWatchFolderUri!!)}"
            autoWatchFolderLabel.setTextColor(getColor(R.color.color_success))
        }
        p.getString(KEY_YTS_DOMAIN, null)?.let { saved ->
            ytsDomainInput.setText(saved)
            if (saved.startsWith("http")) {
                val parsed = parseYtsExampleUrl(saved)
                ytsDomain        = parsed.first
                ytsSearchPattern = parsed.second
            } else {
                ytsDomain = saved
            }
            ytsSearchPatternInput.setText(ytsSearchPattern)
        }
        p.getString(KEY_YTS_PATTERN, null)?.let { pat ->
            if (ytsSearchPattern == "/movies/{slug}") {
                ytsSearchPattern = pat
                ytsSearchPatternInput.setText(pat)
            }
        }
        p.getString(KEY_YTS_SELECTOR, null)?.let { sel ->
            ytsTorrentSelector = sel
            ytsTorrentSelectorInput.setText(sel)
        }

        // ── Load bt4g sites ───────────────────────────────────────────
        val sitesJson = p.getString(KEY_BT4G_SITES, null)
        if (sitesJson != null) {
            try {
                val arr = org.json.JSONArray(sitesJson)
                bt4gSites.clear()
                for (i in 0 until arr.length()) {
                    val obj = arr.getJSONObject(i)
                    bt4gSites.add(Bt4gSite(
                        name     = obj.optString("name"),
                        domain   = obj.optString("domain"),
                        pattern  = obj.optString("pattern"),
                        selector = obj.optString("selector"),
                        steps    = run {
                            val arr2 = obj.optJSONArray("steps")
                            if (arr2 != null) (0 until arr2.length()).map { arr2.getString(it) }
                            else emptyList()
                        }
                    ))
                }
            } catch (_: Exception) {}
        }
        if (bt4gSites.isEmpty()) {
            bt4gSites.addAll(DEFAULT_SITES)
        }
        bt4gCurrentSiteIndex = p.getInt(KEY_BT4G_SITE_IDX, 0).coerceIn(0, bt4gSites.size - 1)
        applyCurrentSite()

        // ── backward compat: old single-site prefs ────────────────────
        if (bt4gSites.size == DEFAULT_SITES.size) {
            p.getString(KEY_BT4G_DOMAIN, null)?.let { saved ->
                bt4gDomainInput.setText(saved)
            }
            p.getString(KEY_BT4G_PATTERN, null)?.let { pat ->
                bt4gSearchPatternInput.setText(pat)
            }
            p.getString(KEY_BT4G_SELECTOR, null)?.let { sel ->
                bt4gMagnetSelectorInput.setText(sel)
            }
        }

        if (p.getBoolean(KEY_AUTO_RUNNING, false)) startAuto()
    }

    /** يطبّق الموقع الحالي على الحقول والمتغيرات */
    private fun applyCurrentSite() {
        if (bt4gSites.isEmpty()) return
        val site = bt4gSites[bt4gCurrentSiteIndex]
        bt4gDomain         = site.domain
        bt4gSearchPattern  = site.pattern
        bt4gMagnetSelector = site.selector
        bt4gSteps          = site.steps
        bt4gCurrentStep    = 0
        bt4gSiteLabel.text      = site.name
        bt4gSiteDropdownBtn.text = site.name
        bt4gDomainInput.setText(site.domain)
        bt4gSearchPatternInput.setText(site.pattern)
        // في الـ UI: لو في خطوات، عرّضها بدل الـ selector الواحد
        if (site.steps.isNotEmpty()) {
            bt4gMagnetSelectorInput.setText(site.steps.joinToString("\n"))
        } else {
            bt4gMagnetSelectorInput.setText(site.selector)
        }
    }

    /** يعرض popup menu بكل المواقع المحفوظة */
    private fun showSiteDropdown() {
        val menu = android.widget.PopupMenu(this, bt4gSiteDropdownBtn)
        bt4gSites.forEachIndexed { i, site ->
            val item = menu.menu.add(0, i, i, site.name)
            if (i == bt4gCurrentSiteIndex) item.title = "✓ ${site.name}"
        }
        menu.menu.add(0, bt4gSites.size,     bt4gSites.size,     "➕ إضافة موقع جديد")
        menu.menu.add(0, bt4gSites.size + 1, bt4gSites.size + 1, "✏️ تعديل الموقع الحالي")
        menu.setOnMenuItemClickListener { menuItem ->
            when (val idx = menuItem.itemId) {
                bt4gSites.size     -> showAddSiteDialog()
                bt4gSites.size + 1 -> showAddSiteDialog(editIndex = bt4gCurrentSiteIndex)
                else -> {
                    bt4gCurrentSiteIndex = idx
                    applyCurrentSite()
                    savePrefs()
                    Toast.makeText(this, "✅ تم الاختيار: ${bt4gSites[idx].name}", Toast.LENGTH_SHORT).show()
                    // أخفي الإعدادات بعد الاختيار
                    if (bt4gSettingsExpanded) {
                        bt4gSettingsExpanded = false
                        bt4gSettingsBody.visibility = View.GONE
                        bt4gSettingsToggle.text = "⚙️ الموقع الحالي  ▼"
                    }
                }
            }
            true
        }
        menu.show()
    }

    /** يعرض dialog لإضافة موقع جديد عبر URL مثال */
    private fun showAddSiteDialog(editIndex: Int = -1) {
        val isEdit = editIndex >= 0 && editIndex < bt4gSites.size
        val existing = if (isEdit) bt4gSites[editIndex] else null

        val ctx = this
        val scroll = android.widget.ScrollView(ctx)
        val layout = android.widget.LinearLayout(ctx).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setPadding(48, 24, 48, 16)
        }
        scroll.addView(layout)

        // ── اسم الموقع ───────────────────────────────────────────────
        layout.addView(android.widget.TextView(ctx).apply {
            text = "📛 اسم الموقع"; textSize = 13f; setPadding(0, 0, 0, 4)
        })
        val nameInput = android.widget.EditText(ctx).apply {
            hint = "مثال: bitsearch.eu"
            setSingleLine()
            setText(existing?.name ?: "")
        }
        layout.addView(nameInput)

        // ── URL مثال للسرش ───────────────────────────────────────────
        layout.addView(android.widget.TextView(ctx).apply {
            text = "🔗 URL مثال للسرش"; textSize = 13f; setPadding(0, 16, 0, 4)
        })
        layout.addView(android.widget.TextView(ctx).apply {
            text = "حط URL سرش كامل — التطبيق هيستخلص الدومين والـ pattern أوتوماتيك"
            textSize = 10f; setTextColor(0xFF888888.toInt()); setPadding(0, 0, 0, 6)
        })
        val urlInput = android.widget.EditText(ctx).apply {
            hint = "https://bitsearch.eu/search?q=Half.Man.S01"
            setSingleLine()
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_URI
            setText(if (isEdit) {
                val pat = existing!!.pattern.replace("{query}", "EXAMPLE").replace("{q}", "EXAMPLE")
                existing.domain + pat
            } else "")
        }
        layout.addView(urlInput)

        // ── الخطوات ──────────────────────────────────────────────────
        layout.addView(android.widget.TextView(ctx).apply {
            text = "🧲 خطوات الوصول للتورنت"; textSize = 13f; setPadding(0, 16, 0, 2)
        })
        layout.addView(android.widget.TextView(ctx).apply {
            text = "كل خطوة هي CSS Selector للعنصر اللي التطبيق هيضغط عليه\n" +
                   "الخطوة الأخيرة لازم توصّل لـ magnet أو torrent\n" +
                   "لو المغنيت موجود مباشرة في صفحة السرش ← خطوة واحدة بس"
            textSize = 10f; setTextColor(0xFF888888.toInt()); setPadding(0, 0, 0, 8)
        })

        // Container للخطوات الديناميكية
        val stepsContainer = android.widget.LinearLayout(ctx).apply {
            orientation = android.widget.LinearLayout.VERTICAL
        }
        layout.addView(stepsContainer)

        // قائمة الـ EditTexts للخطوات
        val stepInputs = mutableListOf<android.widget.EditText>()

        fun addStepRow(value: String = "") {
            val stepNum = stepInputs.size + 1
            val row = android.widget.LinearLayout(ctx).apply {
                orientation = android.widget.LinearLayout.HORIZONTAL
                gravity = android.view.Gravity.CENTER_VERTICAL
                setPadding(0, 4, 0, 4)
            }
            val label = android.widget.TextView(ctx).apply {
                text = "$stepNum"
                textSize = 12f
                setTextColor(0xFF888888.toInt())
                setPadding(0, 0, 10, 0)
                minWidth = 24
                gravity = android.view.Gravity.CENTER
            }
            val input = android.widget.EditText(ctx).apply {
                layoutParams = android.widget.LinearLayout.LayoutParams(0, android.widget.LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                hint = when (stepNum) {
                    1 -> "h3 a[href^='/torrent/']  ← اضغط العنوان"
                    2 -> "a[href*='/download/torrent/']  ← اضغط Torrent"
                    else -> "CSS Selector للخطوة $stepNum"
                }
                setSingleLine()
                setText(value)
            }
            val delBtn = android.widget.Button(ctx).apply {
                text = "✕"
                textSize = 12f
                setPadding(12, 0, 12, 0)
                setBackgroundColor(0x00000000)
                setTextColor(0xFFFF5555.toInt())
                setOnClickListener {
                    stepsContainer.removeView(row)
                    stepInputs.remove(input)
                    // أعد ترقيم الـ labels
                    stepInputs.forEachIndexed { i, et ->
                        (et.parent as? android.widget.LinearLayout)
                            ?.getChildAt(0)?.let { lbl ->
                                (lbl as? android.widget.TextView)?.text = "${i + 1}"
                            }
                    }
                }
            }
            row.addView(label)
            row.addView(input)
            row.addView(delBtn)
            stepsContainer.addView(row)
            stepInputs.add(input)
        }

        // ابدأ بخطوة واحدة على الأقل، أو حمّل الخطوات الموجودة
        if (isEdit && existing!!.steps.isNotEmpty()) {
            existing.steps.forEach { addStepRow(it) }
        } else if (isEdit && existing!!.selector.isNotEmpty()) {
            addStepRow(existing.selector)
        } else {
            addStepRow()  // خطوة فاضية أولى
        }

        // زرار + إضافة خطوة
        val addStepBtn = android.widget.Button(ctx).apply {
            text = "+ إضافة خطوة"
            textSize = 12f
            setOnClickListener { addStepRow() }
        }
        layout.addView(addStepBtn)

        val title = if (isEdit) "✏️ تعديل موقع" else "➕ إضافة موقع جديد"
        android.app.AlertDialog.Builder(ctx)
            .setTitle(title)
            .setView(scroll)
            .setPositiveButton("💾 حفظ") { _, _ ->
                val name   = nameInput.text.toString().trim()
                val rawUrl = urlInput.text.toString().trim()
                if (name.isEmpty() || rawUrl.isEmpty()) {
                    Toast.makeText(ctx, "⚠️ الاسم والـ URL مطلوبين", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                val exUrl  = if (rawUrl.startsWith("http")) rawUrl else "https://$rawUrl"
                val parsed = parseBt4gExampleUrl(exUrl)

                val steps = stepInputs.map { it.text.toString().trim() }.filter { it.isNotEmpty() }
                val newSite = when {
                    steps.size > 1 -> Bt4gSite(name, parsed.first, parsed.second, "", steps)
                    steps.size == 1 -> Bt4gSite(name, parsed.first, parsed.second, steps[0])
                    else -> Bt4gSite(name, parsed.first, parsed.second, "")
                }

                if (isEdit) {
                    bt4gSites[editIndex] = newSite
                    if (bt4gCurrentSiteIndex == editIndex) applyCurrentSite()
                    Toast.makeText(ctx, "✅ تم التعديل: $name", Toast.LENGTH_SHORT).show()
                } else {
                    bt4gSites.add(newSite)
                    bt4gCurrentSiteIndex = bt4gSites.size - 1
                    applyCurrentSite()
                    val info = if (steps.size > 1) " (${steps.size} خطوات)" else ""
                    Toast.makeText(ctx, "✅ تم إضافة: $name$info", Toast.LENGTH_SHORT).show()
                }
                savePrefs()
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    // ═══════════════════════════════════════════════════════════════════
    //  AUTO BT4G TAB
    // ═══════════════════════════════════════════════════════════════════

    /**
     * بيبني JS للخطوة الحالية:
     *  - لو الـ step الأخير (أو selector واحد): يدور على magnet/torrent ويفتحه
     *  - لو خطوة وسطى: يجيب الـ href ويعمل window.location.href (مش click) → يضمن onPageFinished
     */
    private fun buildStepJs(sel: String, isLast: Boolean, stepNum: Int): String {
        val esc = sel.replace("\\", "\\\\").replace("'", "\\'")
        return if (isLast) {
            // الخطوة الأخيرة: دور على magnet أو torrent وافتحه
            """(function() {
              var att = 0;
              function run() {
                att++;
                // جرب الـ selector المحدد أولاً
                var el = document.querySelector('$esc');
                if (el) {
                  var href = el.href || el.getAttribute('href') || '';
                  if (href.startsWith('magnet:')) { AndroidBridge.openMagnet(href); return; }
                  if (href.includes('/torrent') || href.includes('/download') || href.endsWith('.torrent')) {
                    AndroidBridge.openTorrentUrl(href); return;
                  }
                }
                // fallback: أي magnet في الصفحة
                var mags = document.querySelectorAll('a[href^="magnet:"]');
                if (mags.length > 0) { AndroidBridge.openMagnet(mags[0].href); return; }
                // fallback: أي torrent download
                var tors = document.querySelectorAll('a[href*="/download/torrent"],a[href*="/torrent/download"],a[href$=".torrent"]');
                if (tors.length > 0) { AndroidBridge.openTorrentUrl(tors[0].href); return; }
                if (att < 12) setTimeout(run, 700);
                else AndroidBridge.onStatus('❌ مفيش magnet أو torrent في خطوة $stepNum');
              }
              run();
            })();"""
        } else {
            // خطوة وسطى: انتقل للصفحة الجاية بـ location.href مش click
            // لأن click في SPAs ممكن ميعملش navigation حقيقي
            """(function() {
              var att = 0;
              function run() {
                att++;
                var el = document.querySelector('$esc');
                if (el) {
                  var href = el.href || el.getAttribute('href') || '';
                  if (!href || href === '#') { el.click(); AndroidBridge.onStepAdvance(); return; }
                  // لو رابط نسبي حوّله لكامل
                  if (!href.startsWith('http') && !href.startsWith('magnet:')) {
                    href = window.location.origin + (href.startsWith('/') ? '' : '/') + href;
                  }
                  if (href.startsWith('magnet:')) { AndroidBridge.openMagnet(href); return; }
                  // خطوة وسطى: لو رابط .torrent حقيقي (مش صفحة تفاصيل) افتحه
                  if (href.endsWith('.torrent') ||
                      (href.includes('/download/torrent') && !href.includes('/details') && !href.includes('/info'))) {
                    AndroidBridge.openTorrentUrl(href); return;
                  }
                  // غير كده: انتقل للصفحة (سواء كانت /details أو /info أو أي صفحة تانية)
                  AndroidBridge.onStatus('⏳ خطوة $stepNum...');
                  AndroidBridge.onStepAdvance();
                  window.location.href = href;
                  return;
                }
                if (att < 12) setTimeout(run, 700);
                else AndroidBridge.onStatus('❌ مش لاقي العنصر في خطوة $stepNum');
              }
              run();
            })();"""
        }
    }

    private fun buildAutoJs(): String {
        val host = try { Uri.parse(bt4gDomain).host ?: "bt4gprx.com" } catch (_: Exception) { "bt4gprx.com" }

        // ── Multi-step mode ─────────────────────────────────────────
        if (bt4gSteps.isNotEmpty()) {
            val step = bt4gCurrentStep.coerceIn(0, bt4gSteps.size - 1)
            val sel  = bt4gSteps[step].trim()
            val isLast = (step == bt4gSteps.size - 1)
            return buildStepJs(sel, isLast, step + 1)
        }

        val sel = bt4gMagnetSelector.trim()
        return if (sel.isNotEmpty()) {
            // ── Direct single-selector mode ───────────────────────────
            buildStepJs(sel, isLast = true, stepNum = 1)
        } else {
            // ── bt4g original 3-step flow ─────────────────────────────
            """(function() {
              var url = window.location.href;
              if (url.includes('$host/search')) {
                var link = document.querySelector('.list-group-item h5 a');
                if (link) {
                  var u = new URL(link.href, window.location.origin);
                  u.searchParams.set('autodl','1'); window.location.href = u.href;
                } else { AndroidBridge.onStatus('❌ مفيش نتايج'); }
              } else if (url.includes('$host/magnet')) {
                var btn = document.querySelector('a[href*="downloadtorrentfile.com"]');
                if (btn) { var u2=new URL(btn.href); u2.searchParams.set('autodl','1'); window.location.href=u2.href; }
              } else if (url.includes('downloadtorrentfile.com')) {
                var m = document.querySelector('a#open[href^="magnet:"]');
                if (m) { AndroidBridge.openMagnet(m.href); }
                else { AndroidBridge.onStatus('⏳ جاري...'); setTimeout(function(){location.reload();},2000); }
              }
            })();"""
        }
    }

    private fun setupBt4g() {
        CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(bt4gWebView, true)
        }
        bt4gWebView.settings.apply {
            javaScriptEnabled = true; domStorageEnabled = true; databaseEnabled = true
            setSupportZoom(false); loadWithOverviewMode = true; useWideViewPort = true
            userAgentString = "Mozilla/5.0 (Linux; Android 13; Pixel 7) " +
                "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"
        }
        bt4gWebView.addJavascriptInterface(object {
            @JavascriptInterface
            fun openMagnet(magnetUrl: String) = runOnUiThread {
                bt4gStatusText.text = "✅ تم! بيفتح..."
                bt4gProgressBar.visibility = View.GONE
                bt4gWebView.visibility = View.GONE; showSpacers(true); bt4gCfRetries = 0
                openMagnetLink(magnetUrl)
            }
            @JavascriptInterface
            fun openTorrentUrl(torrentUrl: String) = runOnUiThread {
                bt4gStatusText.text = "✅ تم! بيفتح التورنت..."
                bt4gProgressBar.visibility = View.GONE
                bt4gWebView.visibility = View.GONE; showSpacers(true); bt4gCfRetries = 0
                openBt4gTorrentOrMagnet(torrentUrl)
            }
            @JavascriptInterface
            fun onStatus(msg: String) = runOnUiThread { bt4gStatusText.text = msg }
            @JavascriptInterface
            fun onStepAdvance() = runOnUiThread {
                // الـ JS بيستدعي ده قبل window.location.href مباشرة
                // فـ onPageFinished اللي هيجي هيلاقي الـ step محدّث
                if (bt4gCurrentStep < bt4gSteps.size - 1) {
                    bt4gCurrentStep++
                    bt4gStatusText.text = "⏳ خطوة ${bt4gCurrentStep + 1} من ${bt4gSteps.size}..."
                }
            }
        }, "AndroidBridge")
        bt4gWebView.settings.setSupportMultipleWindows(true)
        bt4gWebView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, p: Int) {
                if (p == 100) bt4gProgressBar.visibility = View.GONE
            }
            // اعترض new-tab / popup — بيشتغل لو الصفحة استخدمت target="_blank" أو window.open
            override fun onCreateWindow(view: WebView, isDialog: Boolean,
                                         isUserGesture: Boolean, msg: android.os.Message?): Boolean {
                val newWebView = WebView(this@MainActivity)
                newWebView.webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(v: WebView, req: WebResourceRequest): Boolean {
                        val u = req.url.toString()
                        if (u.startsWith("magnet:") ||
                            u.contains("/download/torrent") || u.contains("/torrent/download") ||
                            u.endsWith(".torrent") ||
                            (u.contains("/download") && u.contains("torrent"))) {
                            openBt4gTorrentOrMagnet(u)
                            return true
                        }
                        // رابط عادي — افتحه في نفس الـ WebView
                        bt4gWebView.loadUrl(u); return true
                    }
                }
                val transport = msg?.obj as? WebView.WebViewTransport ?: return false
                transport.webView = newWebView
                msg.sendToTarget()
                return true
            }
        }
        bt4gWebView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView,
                                                   req: WebResourceRequest): Boolean {
                val url = req.url.toString()
                if (url.startsWith("magnet:")) {
                    runOnUiThread {
                        bt4gStatusText.text = "✅ تم! بيفتح..."
                        bt4gProgressBar.visibility = View.GONE
                        bt4gWebView.visibility = View.GONE; showSpacers(true)
                    }
                    openBt4gTorrentOrMagnet(url)
                    return true
                }
                // اعترض torrent download links — بس لو مش في وسط خطوات
                // (لو في خطوات، اسمح للـ WebView يكمل navigation للصفحة التالية)
                // Magnet دايماً بيتعترض
                // .torrent files: بيتعترضوا بس لو مش في وسط خطوات
                // الخطوات بتعمل JS click/navigate بنفسها — مش محتاجين override هنا
                val stepsInProgress = bt4gSteps.isNotEmpty() && bt4gCurrentStep < bt4gSteps.size - 1
                val isTorrentFile = url.endsWith(".torrent") ||
                    (url.contains("/download/torrent") && url.length > 50) ||
                    url.contains("/torrent/download")
                if (isTorrentFile && !stepsInProgress) {
                    runOnUiThread {
                        bt4gStatusText.text = "✅ تم! بيحمّل التورنت..."
                        bt4gProgressBar.visibility = View.GONE
                        bt4gWebView.visibility = View.GONE; showSpacers(true)
                    }
                    openBt4gTorrentOrMagnet(url)
                    return true
                }
                // أي URL تاني (صفحات تفاصيل، نتائج بحث، إلخ) — اسمح للـ WebView يحمّله
                return false
            }
            override fun onPageFinished(view: WebView, url: String) {
                bt4gProgressBar.visibility = View.GONE
                CookieManager.getInstance().flush()
                view.evaluateJavascript("""(function(){
                    var t=document.title||'';
                    return (t.toLowerCase().includes('just a moment')||
                            t.toLowerCase().includes('checking'))?'cf':'ok';
                })()""") { r ->
                    if (r?.trim('"') == "cf") {
                        if (bt4gCfRetries++ < 6) {
                            runOnUiThread { bt4gStatusText.text = "🔐 Cloudflare... ($bt4gCfRetries/6)" }
                            bt4gWebView.postDelayed(
                                { view.evaluateJavascript("window.scrollTo(0,0);", null) }, 2500)
                        } else runOnUiThread { bt4gStatusText.text = "⚠️ Cloudflare — جرب تاني" }
                        return@evaluateJavascript
                    }
                    bt4gCfRetries = 0

                    // ── inject الـ universal interceptor ──────────────────
                    // بيعترض magnet + torrent clicks حتى لو الصفحة render بـ JS
                    view.evaluateJavascript("""
                        (function() {
                          // الـ handler نفسه — بيتشغل على كل click في الصفحة
                          function handleClick(e) {
                            var el = e.target;
                            for (var i = 0; i < 8 && el && el.tagName; i++) {
                              if (el.tagName === 'A') {
                                var href = el.getAttribute('href') || '';
                                var abs  = el.href || '';
                                // magnet
                                if (abs.startsWith('magnet:') || href.startsWith('magnet:')) {
                                  e.preventDefault(); e.stopPropagation();
                                  AndroidBridge.openMagnet(abs || href);
                                  return;
                                }
                                // torrent file download
                                var lc = (abs || href).toLowerCase();
                                if (lc.includes('/download/torrent') ||
                                    lc.includes('/torrent/download') ||
                                    lc.endsWith('.torrent') ||
                                    (lc.includes('/download') && lc.includes('torrent'))) {
                                  e.preventDefault(); e.stopPropagation();
                                  AndroidBridge.openTorrentUrl(abs || href);
                                  return;
                                }
                              }
                              el = el.parentElement;
                            }
                          }
                          // احذف القديم لو موجود وحط جديد (بعد كل onPageFinished)
                          document.removeEventListener('click', window.__btHandler, true);
                          window.__btHandler = handleClick;
                          document.addEventListener('click', handleClick, true);
                        })();
                    """.trimIndent(), null)

                    // Direct-magnet mode: run JS on any page from our domain
                    val isOurPage = try {
                        val pageHost = Uri.parse(url).host ?: ""
                        val ourHost  = Uri.parse(bt4gDomain).host ?: ""
                        pageHost == ourHost ||
                            pageHost.endsWith(".$ourHost") ||
                            ourHost.endsWith(".$pageHost") ||
                            url.contains("downloadtorrentfile.com")
                    } catch (_: Exception) { true }

                    // لو في steps فعّالة ومش وصلنا لآخر page: شغّل الخطوة على أي صفحة
                    // (الخطوات ممكن تروح لصفحات على نفس الدومين بس paths مختلفة)
                    val stepsActive = bt4gSteps.isNotEmpty() && bt4gCurrentStep < bt4gSteps.size

                    if (stepsActive) {
                        // Multi-step mode — شغّل الخطوة الحالية بعد تحميل الصفحة
                        val js = buildAutoJs()
                        view.postDelayed({ bt4gWebView.evaluateJavascript(js, null) }, 800)
                        view.postDelayed({ bt4gWebView.evaluateJavascript(buildAutoJs(), null) }, 2200)
                        view.postDelayed({ bt4gWebView.evaluateJavascript(buildAutoJs(), null) }, 4000)
                    } else if (bt4gMagnetSelector.isNotEmpty() && isOurPage) {
                        view.postDelayed({ bt4gWebView.evaluateJavascript(buildAutoJs(), null) }, 800)
                    } else if (url.contains("autodl=1")) {
                        bt4gWebView.evaluateJavascript(buildAutoJs(), null)
                    }
                    bt4gPendingQuery?.let { q -> bt4gPendingQuery = null; bt4gSearch(q) }

                    // re-inject بعد 1.5 ثانية للصفحات اللي بتتبني بـ JS (React/SPA)
                    view.postDelayed({
                        view.evaluateJavascript("""
                            (function() {
                              function handleClick(e) {
                                var el = e.target;
                                for (var i = 0; i < 8 && el && el.tagName; i++) {
                                  if (el.tagName === 'A') {
                                    var href = el.getAttribute('href') || '';
                                    var abs  = el.href || '';
                                    if (abs.startsWith('magnet:') || href.startsWith('magnet:')) {
                                      e.preventDefault(); e.stopPropagation();
                                      AndroidBridge.openMagnet(abs || href); return;
                                    }
                                    var lc = (abs || href).toLowerCase();
                                    if (lc.includes('/download/torrent') || lc.includes('/torrent/download') ||
                                        lc.endsWith('.torrent') || (lc.includes('/download') && lc.includes('torrent'))) {
                                      e.preventDefault(); e.stopPropagation();
                                      AndroidBridge.openTorrentUrl(abs || href); return;
                                    }
                                  }
                                  el = el.parentElement;
                                }
                              }
                              document.removeEventListener('click', window.__btHandler, true);
                              window.__btHandler = handleClick;
                              document.addEventListener('click', handleClick, true);
                            })();
                        """.trimIndent(), null)
                    }, 1500L)
                }
            }
        }
        bt4gSearchBtn.setOnClickListener {
            val q = bt4gSearchInput.text.toString().trim()
            if (q.isNotEmpty()) { bt4gCfRetries = 0; bt4gSearch(q) }
            else Toast.makeText(this, "اكتب اسم الفيلم", Toast.LENGTH_SHORT).show()
        }

        bt4gSiteDropdownBtn.setOnClickListener { showSiteDropdown() }
        bt4gAddSiteBtn.setOnClickListener { showAddSiteDialog() }
        bt4gAddStepBtn.setOnClickListener { showAddSiteDialog(editIndex = bt4gCurrentSiteIndex) }

        // ── Collapse / expand settings body ─────────────────────────────
        val toggleSettings: () -> Unit = {
            bt4gSettingsExpanded = !bt4gSettingsExpanded
            bt4gSettingsBody.visibility = if (bt4gSettingsExpanded) View.VISIBLE else View.GONE
            val arrow = if (bt4gSettingsExpanded) "▲" else "▼"
            bt4gSettingsToggle.text = "⚙️ الموقع الحالي  $arrow"
        }
        bt4gSettingsToggle.setOnClickListener { toggleSettings() }
        bt4gSettingsCard.setOnClickListener { /* absorb tap on card itself */ }

        bt4gDomainSaveBtn.setOnClickListener {
            val rawExample = bt4gDomainInput.text.toString().trim().trimEnd('/')
            val rawSel     = bt4gMagnetSelectorInput.text.toString().trim()

            if (rawExample.isEmpty()) {
                Toast.makeText(this, "⚠️ حط URL مثال كامل للسرش", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val exampleUrl = if (rawExample.startsWith("http")) rawExample else "https://$rawExample"
            val parsed     = parseBt4gExampleUrl(exampleUrl)
            bt4gDomain        = parsed.first
            bt4gSearchPattern = parsed.second

            // لو في أكتر من سطر = خطوات متعددة
            val stepLines = rawSel.lines().map { it.trim() }.filter { it.isNotEmpty() }
            if (stepLines.size > 1) {
                bt4gSteps          = stepLines
                bt4gMagnetSelector = ""
                bt4gCurrentStep    = 0
            } else {
                bt4gMagnetSelector = stepLines.firstOrNull() ?: ""
                bt4gSteps          = emptyList()
                bt4gCurrentStep    = 0
            }

            bt4gDomainInput.setText(exampleUrl)
            bt4gSearchPatternInput.setText(bt4gSearchPattern)
            bt4gMagnetSelectorInput.setText(rawSel)

            // ── حدّث أو أضف الموقع في الـ list ──────────────────────────
            val siteName = try { Uri.parse(bt4gDomain).host ?: bt4gDomain } catch (_: Exception) { bt4gDomain }
            val updatedSite = if (bt4gSteps.isNotEmpty()) {
                Bt4gSite(siteName, bt4gDomain, bt4gSearchPattern, "", bt4gSteps)
            } else {
                Bt4gSite(siteName, bt4gDomain, bt4gSearchPattern, bt4gMagnetSelector)
            }
            if (bt4gCurrentSiteIndex < bt4gSites.size) {
                bt4gSites[bt4gCurrentSiteIndex] = updatedSite
            } else {
                bt4gSites.add(updatedSite)
                bt4gCurrentSiteIndex = bt4gSites.size - 1
            }
            bt4gSiteLabel.text      = siteName
            bt4gSiteDropdownBtn.text = siteName
            savePrefs()
            val stepsInfo = if (bt4gSteps.size > 1) "\nخطوات: ${bt4gSteps.size}" else if (bt4gMagnetSelector.isNotEmpty()) "\nSelector: $bt4gMagnetSelector" else ""
            Toast.makeText(this,
                "✅ تم الحفظ:\nدومين: $bt4gDomain\nTemplate: $bt4gSearchPattern$stepsInfo",
                Toast.LENGTH_LONG).show()
        }
    }

    // ═══════════════════════════════════════════════════════════════════
    //  YTS TAB
    // ═══════════════════════════════════════════════════════════════════

    /** Build a yts slug from "Movie Name 2026" → "movie-name-2026" */
    private fun buildYtsSlug(query: String): Pair<String, String?> {
        val q = query.trim()
        // احذف الأقواس لو موجودة:  "Over Your Dead Body (2026)" → "Over Your Dead Body 2026"
        val cleaned = q.replace(Regex("""[()]"""), " ").trim()
        val yearMatch = Regex("""((?:19|20)\d{2})""").find(cleaned)
        val year = yearMatch?.value
        val name = cleaned.replace(Regex("""((?:19|20)\d{2})"""), "").trim()
        val slug = name.lowercase()
            .replace(Regex("[^a-z0-9]+"), "-")
            .replace(Regex("-+"), "-")
            .trim('-')
        val fullSlug = if (year != null) "$slug-$year" else slug
        return Pair(fullSlug, year)
    }

    /** بيبني JS يستخرج الـ 1080p و 2160p باستخدام الـ selector مع retry loop */
    private fun buildYtsExtractJs(): String {
        val sel = ytsTorrentSelector.trim().ifEmpty { "a[href*=\"/torrent/download/\"]" }
        val escapedSel = sel.replace("\\", "\\\\").replace("'", "\\'")
        return """
        (function() {
          var attempts = 0;
          function extract() {
            attempts++;
            var url1080 = null, url2160 = null;
            var links = document.querySelectorAll('$escapedSel');
            for (var i = 0; i < links.length; i++) {
              var a = links[i];
              var t1 = a.getAttribute('title') || '';
              var t2 = a.textContent || a.innerText || '';
              var t3 = a.getAttribute('href') || '';
              var sig = (t1 + ' ' + t2 + ' ' + t3).toUpperCase();
              var is4k   = sig.includes('2160') || sig.includes('4K') || sig.includes('UHD');
              var is1080 = sig.includes('1080');
              var absUrl = a.href || (window.location.origin + t3);
              if (is4k   && !url2160) { url2160 = absUrl; }
              if (is1080 && !url1080) { url1080 = absUrl; }
            }
            // Fallback: أول رابط مش 4K يبقى 1080
            if (!url1080 && links.length > 0) {
              for (var j = 0; j < links.length; j++) {
                var a2 = links[j];
                var sig2 = ((a2.getAttribute('title') || '') + ' ' +
                            (a2.textContent || '') + ' ' +
                            (a2.getAttribute('href') || '')).toUpperCase();
                if (!sig2.includes('2160') && !sig2.includes('4K') && !sig2.includes('UHD')) {
                  url1080 = a2.href || (window.location.origin + (a2.getAttribute('href') || ''));
                  break;
                }
              }
              if (!url1080) url1080 = links[0].href;
            }
            // لو عندنا الجودتين أو محاولنا كتير → أرسل النتيجة
            if ((url1080 && url2160) || (links.length > 0 && attempts >= 3)) {
              YtsBridge.onTorrentLinks(url1080 || '', url2160 || '');
              return;
            }
            // لو ما لقيناش حاجة ولسه في محاولات
            if (attempts < 12) {
              setTimeout(extract, 800);
            } else {
              YtsBridge.onTorrentLinks(url1080 || '', url2160 || '');
            }
          }
          extract();
        })()""".trimIndent()
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupYts() {
        CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(ytsWebView, true)
        }
        ytsWebView.settings.apply {
            javaScriptEnabled = true; domStorageEnabled = true; databaseEnabled = true
            setSupportZoom(false); loadWithOverviewMode = true; useWideViewPort = true
            userAgentString = "Mozilla/5.0 (Linux; Android 13; Pixel 7) " +
                "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"
        }

        ytsWebView.addJavascriptInterface(object {
            @JavascriptInterface
            fun onTorrentFile(url: String) = runOnUiThread {
                ytsStatusText.text = "✅ جاري فتح التورنت..."
                ytsProgressBar.visibility = View.GONE
                openTorrentOrMagnet(url, "torrent")
            }
            @JavascriptInterface
            fun onStatus(msg: String) = runOnUiThread { ytsStatusText.text = msg }

            @JavascriptInterface
            fun onTorrentLinks(u1080: String, u2160: String) = runOnUiThread {
                ytsProgressBar.visibility = View.GONE
                ytsWebView.visibility     = View.GONE
                ytsShowSpacers(true)
                val has1080 = u1080.isNotEmpty()
                val has2160 = u2160.isNotEmpty()
                if (!has1080 && !has2160) {
                    ytsStatusText.text = "⚠️ لم يُعثر على تورنت — جرب selector تاني"
                    return@runOnUiThread
                }
                ytsUrl1080 = u1080.ifEmpty { null }
                ytsUrl2160 = u2160.ifEmpty { null }

                val toDownload = mutableListOf<Pair<String, String>>()
                if (has1080) toDownload.add(Pair(u1080, "1080p"))
                if (has2160) toDownload.add(Pair(u2160, "2160p"))
                val labels = toDownload.joinToString(" + ") { it.second }

                ytsStatusText.text = "⬇️ جاري تحميل $labels..."

                // افتح كل رابط على LibreTorrent مع فارق 700ms
                // بعد ما ينتهوا كلهم بيفتح downloads كروم
                toDownload.forEachIndexed { idx, (url, label) ->
                    ytsWebView.postDelayed({
                        openTorrentOrMagnet(url, label)
                        // بعد آخر رابط بـ 2 ثانية افتح كروم downloads
                        if (idx == toDownload.lastIndex) {
                            ytsWebView.postDelayed({
                                runOnUiThread {
                                    ytsStatusText.text = "✅ تم إرسال $labels — بيفتح Downloads..."
                                    openChromeDownloads()
                                }
                            }, 2000L)
                        }
                    }, idx * 700L)
                }
            }
        }, "YtsBridge")

        ytsWebView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, p: Int) {
                if (p == 100) ytsProgressBar.visibility = View.GONE
            }
        }

        ytsWebView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, req: WebResourceRequest): Boolean {
                val url = req.url.toString()
                if (url.startsWith("magnet:")) {
                    runOnUiThread {
                        ytsStatusText.text = "✅ جاري فتح التورنت..."
                        ytsProgressBar.visibility = View.GONE
                        ytsWebView.visibility = View.GONE
                        ytsShowSpacers(true)
                    }
                    openTorrentOrMagnet(url, "magnet")
                    return true
                }
                return false
            }

            override fun onPageFinished(view: WebView, url: String) {
                ytsProgressBar.visibility = View.GONE
                CookieManager.getInstance().flush()
                // Check for Cloudflare
                view.evaluateJavascript("""(function(){
                    var t=document.title||'';
                    return (t.toLowerCase().includes('just a moment')||
                            t.toLowerCase().includes('checking'))?'cf':'ok';
                })()""") { r ->
                    if (r?.trim('"') == "cf") {
                        if (ytsCfRetries++ < 6) {
                            runOnUiThread { ytsStatusText.text = "🔐 Cloudflare... ($ytsCfRetries/6)" }
                            ytsWebView.postDelayed(
                                { view.evaluateJavascript("window.scrollTo(0,0);", null) }, 2500)
                        } else runOnUiThread { ytsStatusText.text = "⚠️ Cloudflare — جرب تاني" }
                        return@evaluateJavascript
                    }
                    ytsCfRetries = 0
                    // شغّل الـ scraping لما بيبقى على صفحة فيلم
                    val ytsHost = try { Uri.parse(ytsDomain).host ?: "" } catch (_: Exception) { "" }
                    val pattern = ytsSearchPattern.ifEmpty { "/movies/{slug}" }
                    // الجزء الثابت من الـ pattern قبل الـ placeholder
                    val patternPrefix = pattern
                        .substringBefore("{slug}")
                        .substringBefore("{query}")
                        .substringBefore("{q}")
                        .trimEnd('/')
                    val isMoviePage = (patternPrefix.isNotEmpty() && url.contains(patternPrefix)) ||
                                     url.contains("/movies/")
                    if (isMoviePage && (ytsHost.isEmpty() || url.contains(ytsHost))) {
                        // ابدأ الـ extraction بعد 800ms — الـ JS نفسه هيعمل retry loop
                        view.postDelayed({
                            view.evaluateJavascript(buildYtsExtractJs()) { /* YtsBridge.onTorrentLinks */ }
                        }, 800L)
                    }
                }
            }
        }

        ytsSearchBtn.setOnClickListener {
            val q = ytsSearchInput.text.toString().trim()
            if (q.isNotEmpty()) { ytsCfRetries = 0; ytsSearch(q) }
            else Toast.makeText(this, "اكتب اسم الفيلم", Toast.LENGTH_SHORT).show()
        }

        ytsSearchInput.setOnEditorActionListener { _, _, _ ->
            val q = ytsSearchInput.text.toString().trim()
            if (q.isNotEmpty()) { ytsCfRetries = 0; ytsSearch(q) }
            true
        }

        // زر 1080 اليدوي
        ytsBtn1080.setOnClickListener {
            ytsUrl1080?.let { openTorrentOrMagnet(it, "1080p") }
        }
        // زر 2160 اليدوي
        ytsBtn2160.setOnClickListener {
            ytsUrl2160?.let { openTorrentOrMagnet(it, "2160p") }
        }

        ytsDomainSaveBtn.setOnClickListener {
            val rawExample  = ytsDomainInput.text.toString().trim().trimEnd('/')
            val rawSelector = ytsTorrentSelectorInput.text.toString().trim()

            if (rawExample.isEmpty()) {
                Toast.makeText(this, "⚠️ حط URL مثال كامل", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // ── استخلاص domain + pattern من الـ URL المثال ──────────────
            // مثال: https://yts.ninjaproxy1.com/movies/over-your-dead-body-2026
            //   → domain  = https://yts.ninjaproxy1.com
            //   → pattern = /movies/{slug}
            val exampleUrl = if (rawExample.startsWith("http")) rawExample else "https://$rawExample"
            val parsed     = parseYtsExampleUrl(exampleUrl)
            ytsDomain          = parsed.first
            ytsSearchPattern   = parsed.second
            ytsTorrentSelector = rawSelector.ifEmpty { "a[href*=\"/torrent/download/\"]" }

            ytsDomainInput.setText(exampleUrl)            // بيعرض الـ URL المثال كامل
            ytsSearchPatternInput.setText(ytsSearchPattern)
            ytsTorrentSelectorInput.setText(ytsTorrentSelector)
            savePrefs()
            Toast.makeText(this,
                "✅ تم الحفظ:\nدومين: $ytsDomain\nTemplate: $ytsSearchPattern",
                Toast.LENGTH_LONG).show()
        }
    }

    /** بيفتح صفحة Downloads في كروم */
    private fun openChromeDownloads() {
        try {
            val intent = Intent(Intent.ACTION_VIEW).apply {
                data = Uri.parse("chrome://downloads/")
                setPackage("com.android.chrome")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(intent)
        } catch (_: Exception) {
            // كروم مش موجود أو مش بيقبل chrome:// URL — افتح Downloads app
            try {
                val intent = Intent(Intent.ACTION_MAIN).apply {
                    addCategory(Intent.CATEGORY_APP_GALLERY)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                startActivity(intent)
            } catch (_: Exception) { /* مفيش حاجة نعمل */ }
        }
    }

    /**
     * بيأخد URL مثال كامل من YTS ويرجع (domain, searchPattern)
     *
     * مثال:  https://yts.ninjaproxy1.com/movies/over-your-dead-body-2026
     *   → ("https://yts.ninjaproxy1.com",  "/movies/{slug}")
     */
    private fun parseYtsExampleUrl(exampleUrl: String): Pair<String, String> {
        return try {
            val uri    = Uri.parse(exampleUrl)
            val scheme = uri.scheme ?: "https"
            val host   = uri.host   ?: return Pair(exampleUrl, "/movies/{slug}")
            val domain = "$scheme://$host"
            val path   = uri.path?.trimEnd('/') ?: ""
            val lastSlash = path.lastIndexOf('/')
            val template  = if (lastSlash >= 0) path.substring(0, lastSlash + 1) + "{slug}"
                            else "/{slug}"
            Pair(domain, template)
        } catch (_: Exception) {
            Pair(exampleUrl, "/movies/{slug}")
        }
    }

    /**
     * بيأخد URL مثال كامل من BT4G/Bitsearch ويرجع (domain, searchPattern)
     *
     * مثال:  https://bitsearch.eu/search?q=Half.Man.S01E06.720p
     *   → ("https://bitsearch.eu",  "/search?q={query}")
     *
     * مثال:  https://magnetz.eu/search?query=Half.Man.S01E06.720p
     *   → ("https://magnetz.eu",  "/search?query={query}")
     */
    private fun parseBt4gExampleUrl(exampleUrl: String): Pair<String, String> {
        return try {
            val uri    = Uri.parse(exampleUrl)
            val scheme = uri.scheme ?: "https"
            val host   = uri.host   ?: return Pair(exampleUrl, "/search?q={query}")
            val domain = "$scheme://$host"
            val path   = uri.path ?: "/search"
            val queryString = uri.query
            if (queryString.isNullOrEmpty()) {
                val lastSlash = path.lastIndexOf('/')
                val template  = if (lastSlash >= 0) path.substring(0, lastSlash + 1) + "{query}"
                                else "/{query}"
                return Pair(domain, template)
            }
            // أول param = search term، باقي الـ params بتتحفظ كما هي
            val params     = queryString.split("&")
            val firstKey   = params.first().substringBefore("=")
            val otherParams = params.drop(1)
                .joinToString("&") { it.substringBefore("=") + "=" + Uri.decode(it.substringAfter("=", "")) }
            val template = path + "?" + firstKey + "={query}" +
                           (if (otherParams.isNotEmpty()) "&$otherParams" else "")
            Pair(domain, template)
        } catch (_: Exception) {
            Pair(exampleUrl, "/search?q={query}")
        }
    }

    /**
     * يفتح رابط تورنت (.torrent) أو magnet مباشرةً على برنامج التورنت
     * بيجرب LibreTorrent أولاً، لو مش موجود بيفتح بأي intent handler
     */
    /** يفتح torrent URL أو magnet بأي تطبيق تورنت مثبّت */
    private fun openBt4gTorrentOrMagnet(url: String) {
        if (url.startsWith("magnet:")) {
            // Magnet link — ابعته مباشرة
            openMagnetLink(url)
            return
        }
        // .torrent URL — حمّله كـ file ثم افتحه بتطبيق التورنت
        runOnUiThread { bt4gStatusText.text = "⬇️ بيحمّل الملف..." }
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val cacheDir = File(cacheDir, "torrents").apply { mkdirs() }
                // استخرج اسم الملف من الـ URL أو سمّيه عشوائي
                val fileName = run {
                    val raw = url.substringAfterLast('/').substringBefore('?')
                    val name = if (raw.isBlank()) "torrent_${System.currentTimeMillis()}" else raw
                    if (name.endsWith(".torrent")) name else "$name.torrent"
                }
                val file = File(cacheDir, fileName)

                // حمّل الملف مع إرسال الـ cookies والـ headers اللي بيحتاجها الموقع
                val cookieHeader = CookieManager.getInstance().getCookie(url) ?: ""
                val conn = java.net.URL(url).openConnection() as java.net.HttpURLConnection
                conn.apply {
                    requestMethod = "GET"
                    setRequestProperty("User-Agent",
                        "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 Chrome/124.0 Mobile Safari/537.36")
                    setRequestProperty("Referer", bt4gDomain)
                    if (cookieHeader.isNotEmpty()) setRequestProperty("Cookie", cookieHeader)
                    connectTimeout = 15_000
                    readTimeout    = 30_000
                    instanceFollowRedirects = true
                }
                val code = conn.responseCode
                if (code !in 200..299) {
                    runOnUiThread { bt4gStatusText.text = "❌ فشل التحميل (HTTP $code)" }
                    return@launch
                }
                conn.inputStream.use { inp -> file.outputStream().use { out -> inp.copyTo(out) } }

                // افتح الملف بـ FileProvider URI
                val uri = androidx.core.content.FileProvider.getUriForFile(
                    this@MainActivity,
                    "${packageName}.fileprovider",
                    file
                )
                val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                    setDataAndType(uri, "application/x-bittorrent")
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                val chooser = Intent.createChooser(intent, "افتح بـ...").apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                runOnUiThread {
                    bt4gStatusText.text = "✅ جاهز!"
                    try { startActivity(chooser) }
                    catch (_: Exception) {
                        try { startActivity(intent) }
                        catch (e2: Exception) { bt4gStatusText.text = "❌ مفيش تطبيق تورنت مثبّت" }
                    }
                }
            } catch (e: Exception) {
                runOnUiThread { bt4gStatusText.text = "❌ تعذّر التحميل: ${e.message}" }
            }
        }
    }

    /** يفتح magnet link مباشرة بأي تطبيق تورنت */
    private fun openMagnetLink(magnetUrl: String) {
        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(magnetUrl)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            val chooser = Intent.createChooser(intent, "افتح بـ...").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            try { startActivity(chooser) }
            catch (_: Exception) { intent.setPackage(null); startActivity(intent) }
        } catch (e: Exception) {
            runOnUiThread { bt4gStatusText.text = "❌ مفيش تطبيق تورنت مثبّت" }
        }
    }

    private fun openTorrentOrMagnet(url: String, label: String) {
        runOnUiThread {
            try {
                val uri = Uri.parse(url)
                val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    // لو تورنت file بيحدد الـ MIME
                    if (url.contains(".torrent") && !url.startsWith("magnet:")) {
                        type = "application/x-bittorrent"
                    }
                }
                // جرب LibreTorrent أولاً
                try {
                    intent.setPackage("org.proninyaroslav.libretorrent")
                    startActivity(intent)
                } catch (_: Exception) {
                    // جرب flud
                    try {
                        intent.setPackage("com.delphicoder.flud")
                        startActivity(intent)
                    } catch (_: Exception) {
                        // أي تطبيق عنده القدرة
                        intent.setPackage(null)
                        startActivity(intent)
                    }
                }
                ytsStatusText.text = "✅ تم إرسال $label للتورنت"
            } catch (e: Exception) {
                ytsStatusText.text = "❌ تعذّر فتح $label — نزّل LibreTorrent"
            }
        }
    }

    private fun ytsShowSpacers(show: Boolean) {
        fun setW(v: View, w: Float) {
            (v.layoutParams as LinearLayout.LayoutParams).weight = w; v.requestLayout()
        }
        setW(ytsTopSpacer, if (show) 1f else 0f)
        setW(ytsBottomSpacer, if (show) 1f else 0f)
    }

    private fun ytsSearch(query: String) {
        ytsUrl1080 = null; ytsUrl2160 = null
        ytsQualityRow.visibility = View.GONE
        ytsProgressBar.visibility = View.VISIBLE
        ytsStatusText.text = "🔍 $query"
        ytsWebView.visibility = View.VISIBLE
        ytsShowSpacers(false)

        val (slug, _) = buildYtsSlug(query)
        val base      = ytsDomain.trimEnd('/')
        // الـ pattern بيدعم {slug} (اللي بيتحول لـ slug) أو {query} (نص حرفي)
        val pattern   = ytsSearchPattern.ifEmpty { "/movies/{slug}" }
        val path      = pattern
            .replace("{slug}",  slug)
            .replace("{query}", Uri.encode(query))
            .replace("{q}",     Uri.encode(query))

        val url = if (path.startsWith("http")) path else "$base$path"
        ytsStatusText.text = "🔗 $url"
        ytsWebView.loadUrl(url)
    }

    private fun showSpacers(show: Boolean) {
        fun setW(v: View, w: Float) {
            (v.layoutParams as LinearLayout.LayoutParams).weight = w; v.requestLayout()
        }
        setW(bt4gTopSpacer, if (show) 1f else 0f)
        setW(bt4gBottomSpacer, if (show) 1f else 0f)
    }

    private fun bt4gSearch(q: String) {
        bt4gCurrentStep = 0  // reset الخطوات مع كل سرش جديد
        bt4gProgressBar.visibility = View.VISIBLE
        bt4gStatusText.text = "🔍 $q"
        bt4gWebView.visibility = View.VISIBLE; showSpacers(false)
        val base    = bt4gDomain.trimEnd('/')
        val pattern = bt4gSearchPattern.ifEmpty { "/search?q={query}" }
        // بيدعم {query} و {q} — اللي بيتحط من الـ parser هو {query}
        val path    = pattern
            .replace("{query}", Uri.encode(q))
            .replace("{q}",     Uri.encode(q))
        val fullUrl = if (path.startsWith("http")) path else "$base$path"
        bt4gWebView.loadUrl(fullUrl)
    }

    private fun handleShareIntent() {
        if (Intent.ACTION_SEND == intent.action) {
            val t = intent.getStringExtra(Intent.EXTRA_TEXT)?.trim()
            if (!t.isNullOrBlank()) { bt4gSearchInput.setText(t); switchTab(1); bt4gSearch(t) }
        }
    }

    // ═══════════════════════════════════════════════════════════════════
    //  FILE HELPERS
    // ═══════════════════════════════════════════════════════════════════
    companion object {
        const val ACTION_WAKE_AUTO = "com.hassangamal.srtrenamer.WAKE_AUTO"
        val VIDEO_EXTS = setOf("mkv", "mp4", "avi", "mov", "wmv")
    }

    // parentDocId = docId of the FOLDER that directly contains this file
    data class FileEntry(val name: String, val docId: String, val parentDocId: String = "")
    data class ExtFile(val name: String, val content: ByteArray)
    data class ProcessResult(val success: Boolean, val message: String)

    private fun filesInFolder(treeUri: Uri): List<FileEntry> {
        val res = mutableListOf<FileEntry>()
        fun scanDir(dirDocId: String) {
            try {
                val childUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, dirDocId)
                val proj = arrayOf(
                    DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                    DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                    DocumentsContract.Document.COLUMN_MIME_TYPE)
                contentResolver.query(childUri, proj, null, null, null)?.use { c ->
                    val ni = c.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DISPLAY_NAME)
                    val ii = c.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DOCUMENT_ID)
                    val mi = c.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_MIME_TYPE)
                    while (c.moveToNext()) {
                        val name = c.getString(ni) ?: continue
                        val id   = c.getString(ii) ?: continue
                        val mime = c.getString(mi) ?: ""
                        if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                            scanDir(id)
                        } else {
                            res.add(FileEntry(name, id, dirDocId))  // ← parentDocId هو الفولدر الحالي
                        }
                    }
                }
            } catch (_: Exception) {}
        }
        return try {
            scanDir(DocumentsContract.getTreeDocumentId(treeUri))
            res
        } catch (_: Exception) { res }
    }

    private fun extractSrtsFromUri(uri: Uri): List<ExtFile>? {
        val out = mutableListOf<ExtFile>()
        return try {
            contentResolver.openInputStream(uri)?.use { inp ->
                ZipInputStream(inp).use { z ->
                    var e = z.nextEntry
                    while (e != null) {
                        if (!e.isDirectory &&
                            e.name.substringAfterLast(".").lowercase() in setOf("srt","ass","ssa"))
                            out.add(ExtFile(e.name.substringAfterLast("/"), z.readBytes()))
                        z.closeEntry(); e = z.nextEntry
                    }
                }
            }
            out
        } catch (_: Exception) { null }
    }

    /**
     * يكتب [content] بإسم [fileName] في الفولدر المحدد بـ [parentDocId].
     * لو [parentDocId] فاضي يكتب في root الشجرة.
     */
    private fun writeFile(
        folder: DocumentFile,
        treeUri: Uri,
        fileName: String,
        content: ByteArray,
        parentDocId: String = ""
    ) {
        val targetDocId = parentDocId.ifBlank { DocumentsContract.getTreeDocumentId(treeUri) }
        val parentUri   = DocumentsContract.buildDocumentUriUsingTree(treeUri, targetDocId)

        // احذف نسخة قديمة في نفس الفولدر لو موجودة
        try {
            val childUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, targetDocId)
            contentResolver.query(
                childUri,
                arrayOf(DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                        DocumentsContract.Document.COLUMN_DISPLAY_NAME),
                null, null, null
            )?.use { c ->
                val ii = c.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DOCUMENT_ID)
                val ni = c.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DISPLAY_NAME)
                while (c.moveToNext()) {
                    if (c.getString(ni) == fileName) {
                        DocumentsContract.deleteDocument(
                            contentResolver,
                            DocumentsContract.buildDocumentUriUsingTree(treeUri, c.getString(ii))
                        )
                        break
                    }
                }
            }
        } catch (_: Exception) {}

        try {
            val newUri = DocumentsContract.createDocument(
                contentResolver, parentUri,
                "application/x-subrip", fileName.removeSuffix(".srt")
            ) ?: return
            contentResolver.openOutputStream(newUri)?.use { it.write(content) }
            val cur = contentResolver.query(newUri,
                arrayOf(DocumentsContract.Document.COLUMN_DISPLAY_NAME), null, null, null)
            val created = cur?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
            if (created != null && created != fileName)
                DocumentsContract.renameDocument(contentResolver, newUri, fileName)
        } catch (_: Exception) {
            try {
                val fb = DocumentsContract.createDocument(
                    contentResolver, parentUri,
                    "application/octet-stream", fileName
                ) ?: return
                contentResolver.openOutputStream(fb)?.use { it.write(content) }
            } catch (_: Exception) {}
        }
    }

    // ═══════════════════════════════════════════════════════════════════
    //  STRING / NAME HELPERS
    // ═══════════════════════════════════════════════════════════════════
    private fun buildSlug(title: String) = title.lowercase()
        .replace("'s", "s").replace("'", "").replace("&", "and")
        .replace(Regex("[^a-z0-9]+"), "-")
        .replace(Regex("-+"), "-").trim('-')

    private fun slugAndName(raw: String): Pair<String, String> {
        val validExts = setOf("mkv","mp4","avi","mov","wmv","flv","srt")
        var n = raw
        for (ext in validExts)
            if (n.lowercase().endsWith(".$ext")) { n = n.dropLast(ext.length + 1); break }
        val yr   = Regex("(19|20)\\d{2}").find(n)
        val se   = Regex("[Ss]\\d{2}[Ee]").find(n)
        val cut  = listOfNotNull(yr?.range?.first, se?.range?.first).minOrNull() ?: -1
        val year = yr?.value ?: ""
        val titleRaw = (if (cut != -1) n.substring(0, cut) else n.substringBefore("."))
            .replace(Regex("[^a-zA-Z0-9]"), " ").trim()
            .split(" ").joinToString(" ") { w ->
                w.lowercase().replaceFirstChar { it.uppercase() } }
        val friendly = if (year.isNotEmpty()) "$titleRaw ($year)" else titleRaw
        val slug = buildString {
            append(titleRaw.replace(" ", "-").lowercase())
            if (year.isNotEmpty()) append("-$year")
        }.replace(Regex("-+"), "-").trim('-')
        return slug to friendly
    }

    private fun folderDisplayName(uri: Uri) =
        uri.lastPathSegment?.substringAfter(":")?.substringAfterLast("/") ?: "Unknown"

    private fun cleanTitle(n: String): String {
        val yr = Regex("(19|20)\\d{2}").find(n)?.range?.first ?: n.length
        val sc = Regex("[Ss]\\d{2}[Ee]").find(n)?.range?.first ?: n.length
        return n.substring(0, minOf(yr, sc))
            .replace(Regex("[^a-zA-Z0-9]"), " ").trim().lowercase()
    }

    private fun similarity(a: String, b: String): Double {
        val w1 = a.split(" ").filter { it.isNotBlank() }.toSet()
        val w2 = b.split(" ").filter { it.isNotBlank() }.toSet()
        if (w1.isEmpty() || w2.isEmpty()) return 0.0
        return w1.intersect(w2).size.toDouble() / maxOf(w1.size, w2.size)
    }

    private fun getFileName(uri: Uri) =
        contentResolver.query(uri, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (i >= 0) c.getString(i) else null
            } else null
        }

    // ── UI helpers ───────────────────────────────────────────────────
    private fun showStatus(ok: Boolean, msg: String) {
        progressBar.visibility = View.GONE
        layoutStatus.visibility = View.VISIBLE
        tvResult.text = msg
        tvResult.setTextColor(getColor(if (ok) R.color.color_success else R.color.color_warning))
    }

    private fun setButtonsEnabled(en: Boolean) {
        btnSelectFolder.isEnabled = en; btnSelectZip.isEnabled = en
        btnRun.isEnabled = en && selectedFolderUri != null && selectedZipUri != null
    }

    private fun resetSrtState() {
        layoutModeChoice.visibility  = View.GONE
        layoutAutoMode.visibility    = View.GONE
        layoutManualMode.visibility  = View.GONE
        btnRun.visibility            = View.GONE
        layoutStatus.visibility      = View.GONE
        btnCheckDownloads.visibility = View.GONE
    }

    override fun onResume() {
        super.onResume()
        isActivityVisible = true
        // إذا اتفتحنا علشان ملف جديد في Auto، انتقل لتاب Auto
        if (intent?.action == ACTION_WAKE_AUTO) {
            switchTab(3)
            intent?.action = null
        }
        if (wentToSubsource && selectedFolderUri != null) {
            wentToSubsource = false; openDownloadsPicker()
        }
    }

    override fun onPause() {
        super.onPause()
        isActivityVisible = false
    }

    override fun onNewIntent(newIntent: Intent) {
        super.onNewIntent(newIntent)
        setIntent(newIntent)
        if (newIntent.action == ACTION_WAKE_AUTO) {
            switchTab(3)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        bt4gWebView.destroy()
        ytsWebView.destroy()
        autoWatchJob?.cancel()
    }
}
